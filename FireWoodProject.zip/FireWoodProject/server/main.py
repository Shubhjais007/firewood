from flask import Flask,jsonify,request,make_response
from flask_mysqldb import MySQL
from datetime import datetime
from flask_cors import CORS 
from flask_bcrypt import Bcrypt
from flask_jwt_extended import JWTManager
from flask_jwt_extended import create_access_token
from flask_mail import Mail, Message

app=Flask(__name__)
mail = Mail(app) # instantiate the mail class

app.config['MYSQL_USER']='root'
app.config['MYSQL_PASSWORD']=''
app.config['MYSQL_DB']='polarstationdb'
app.config['MYSQL_CURSORCLASS']='DictCursor'
app.config['JWT_SECRET_KEY']='secret'

mysql=MySQL(app) 
   
# configuration of mail 
# app.config['MAIL_SERVER']='smtp.gmail.com'
# app.config['MAIL_PORT'] = 465
# app.config['MAIL_USERNAME'] = 'shubhk2712@gmail.com'
# app.config['MAIL_PASSWORD'] = 'Shubham@123#'
# app.config['MAIL_USE_TLS'] = False
# app.config['MAIL_USE_SSL'] = True
# mail = Mail(app) 

app.config['SECRET_KEY'] = 'top-secret!'
app.config['MAIL_SERVER'] = 'smtp.sendgrid.net'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'apikey'
app.config['MAIL_PASSWORD'] = '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'
app.config['MAIL_DEFAULT_SENDER'] = 'shubhk2712@gmail.com'
mail = Mail(app)

bcrypt=Bcrypt(app)
jwt=JWTManager(app)
CORS(app)


@app.route('/user/register',methods=['POST'])
def register():
    cur=mysql.connection.cursor()
    userId=request.get_json()['userId']
    password=bcrypt.generate_password_hash(request.get_json()['password']).decode('utf-8')
    role = str.lower(request.get_json()['role'])

    cur.execute("INSERT INTO user (UserId, Password, Role) VALUES ('"
    +str(userId)+"','"
    +str(password)+"','"
    +str(role)+"')"
    )

    mysql.connection.commit()

    result ={
     "userId": userId,
     "password":password,
     "role": role
    }
    return jsonify({"result":result})

@app.route('/user/login',methods=['POST'])
def login():
    cur=mysql.connection.cursor()
    userId=request.get_json()['userId']
    password=request.get_json()['password']
    result = ""
    cur.execute("SELECT * FROM user where UserId='"+str(userId)+"'")

    rv=cur.fetchone()
    if bcrypt.check_password_hash(rv['Password'],password):
        access_token=create_access_token(identity={'userId':rv['UserId'],'role':rv['Role']})
        result=jsonify({'token':access_token})
    else:
        result=jsonify({"error":"invalid username and password"})

    return result



@app.route('/home/stock',methods=['GET'])
def merchant():
    cur=mysql.connection.cursor()    
    cur.execute("SELECT s.Id, s.DeviceDateTime, s.DeviceId, u.UserId, s.CreditAmount,s.DebitAmount, s.VendLbs, s.AvailableLbs FROM stock as s JOIN user as u on u.Id = s.UserId")

    res = cur.fetchall()    
    stockResp = []

    '''jsonify({"Result":res})`indx``Date_time``merchantId``StoreId``TerminalId`,
     `TransactionId`, `Amount`, `PaymentStatus`, `VendStatus`, `Balance`
    else:
        return make_response(jsonify({"message": "Request body must be JSON"}), 400)'''

    for row in res:
        response_body = {
            "id": row['Id'],
            "date_time": row['DeviceDateTime'],
            "deviceId": row['DeviceId'],
            "userId": row['UserId'],
            "amount": row['CreditAmount'],
            "debitAmount": row['DebitAmount'],
            "vendlbs": row['VendLbs'],
            "availablelbs": row['AvailableLbs']
        }
        stockResp.append(response_body)

    result = make_response(jsonify(stockResp), 200)

    return result

@app.route('/home/userStock',methods=['POST'])
def userTransaction():
    cur=mysql.connection.cursor()
    userId=request.get_json()['userId']

    cur.execute("SELECT s.Id, s.DeviceDateTime, s.DeviceId, u.UserId, s.CreditAmount,s.DebitAmount, s.VendLbs, s.AvailableLbs FROM stock as s join user as u on u.Id = s.UserId where u.userId ='"+str(userId)+"'")

    res = cur.fetchall()    
    stockResp = []
    
    '''jsonify({"Result":res})`indx``Date_time``merchantId``StoreId``TerminalId`,
     `TransactionId`, `Amount`, `PaymentStatus`, `VendStatus`, `Balance`
    else:
        return make_response(jsonify({"message": "Request body must be JSON"}), 400)'''

    for row in res:
        response_body = {
            "id": row['Id'],
            "date_time": row['DeviceDateTime'],
            "deviceId": row['DeviceId'],
            "userId": row['UserId'],
            "amount": row['CreditAmount'],
            "debitAmount": row['DebitAmount'],
            "vendlbs": row['VendLbs'],
            "availablelbs": row['AvailableLbs']
        }
        stockResp.append(response_body)

    result = make_response(jsonify(stockResp), 200)

    return result



@app.route('/home/device',methods=['GET'])
def device():
    cur=mysql.connection.cursor()    
    cur.execute("SELECT d.Id, d.DeviceId, d.Location, u.UserId, d.AvailableLbs, d.Control, d.Status FROM device as d JOIN user as u ON u.Id = d.UserId")

    res = cur.fetchall()    
    deviceRes = []
    
    '''jsonify({"Result":res})`indx``Date_time``merchantId``StoreId``TerminalId`,
     `TransactionId`, `Amount`, `PaymentStatus`, `VendStatus`, `Balance`
    else:
        return make_response(jsonify({"message": "Request body must be JSON"}), 400)'''

    for row in res:
        response_body = {
            "id": row['Id'],
            "deviceId": row['DeviceId'],
            "location": row['Location'],
            "userId": row['UserId'],
            "availablelbs": row['AvailableLbs'],
            "control": row['Control'],
            "status": row['Status']
        }
        deviceRes.append(response_body)

    result = make_response(jsonify(deviceRes), 200)

    return result


@app.route('/home/userDevice',methods=['POST'])
def userDevice():
    cur=mysql.connection.cursor()
    userId=request.get_json()['userId']

    cur.execute("SELECT d.Id, d.DeviceId, d.Location, u.UserId, d.AvailableLbs, d.Control, d.Status FROM device as d JOIN user as u ON u.Id = d.UserId where u.UserId='"+str(userId)+"'")

    res = cur.fetchall()    
    deviceRes = []
    
    '''jsonify({"Result":res})`indx``Date_time``merchantId``StoreId``TerminalId`,
     `TransactionId`, `Amount`, `PaymentStatus`, `VendStatus`, `Balance`
    else:
        return make_response(jsonify({"message": "Request body must be JSON"}), 400)'''

    for row in res:
        response_body = {
            "id": row['Id'],
            "deviceId": row['DeviceId'],
            "location": row['Location'],
            "userId": row['UserId'],
            "availablelbs": row['AvailableLbs'],
            "control": row['Control'],
            "status": row['Status']
        }
        deviceRes.append(response_body)

    result = make_response(jsonify(deviceRes), 200)

    return result

@app.route('/home/addDevice',methods=['POST'])
def addDevice():
    cur=mysql.connection.cursor()

    deviceId=request.get_json()['deviceId']
    userId=request.get_json()['userId']
    location=request.get_json()['location']
    control=request.get_json()['control']
    status="0"
    availablelbs=request.get_json()['availablelbs']

    cur.execute("INSERT INTO device (DeviceId,UserId,Location,Status,Control,AvailableLbs) VALUES ('"+str(deviceId)+"', (select Id from user where UserId = '"+str(userId)+"') ,'"+str(location)+"','"+str(status)+"','"+str(control)+"','"+str(availablelbs)+"')")

    mysql.connection.commit()

    cur.execute("INSERT INTO devicesetting (DeviceId, UserId) VALUES ('"+str(deviceId)+"', (select Id from user where UserId = '"+str(userId)+"')")
    mysql.connection.commit()


    result ={
     "deviceId":deviceId,
     "userId":userId,
     "location":location,
     "availablelbs":availablelbs,
     "control": control,
     "status" : "0"
    }
    return jsonify({"result":result}, 200)


@app.route('/home/deviceStatus',methods=['GET'])
def deviceStatus():
    cur=mysql.connection.cursor()    
    cur.execute("SELECT d.Id, d.DeviceId, d.Location, u.UserId, d.AvailableLbs, d.Control FROM device as d JOIN user as u ON u.Id = d.UserId")

    res = cur.fetchall()    
    deviceRes = []
    
    '''jsonify({"Result":res})`indx``Date_time``merchantId``StoreId``TerminalId`,
     `TransactionId`, `Amount`, `PaymentStatus`, `VendStatus`, `Balance`
    else:
        return make_response(jsonify({"message": "Request body must be JSON"}), 400)'''

    for row in res:
        response_body = {
            "id": row['Id'],
            "deviceId": row['DeviceId'],
            "location": row['Location'],
            "userId": row['UserId'],
            "availablelbs": row['AvailableLbs'],
            "control": row['Control']
        }
        deviceRes.append(response_body)

    result = make_response(jsonify(deviceRes), 200)

    return result



@app.route('/home/updateDevice',methods=['PUT'])
def updateDevice():
    cur=mysql.connection.cursor()
    id=request.get_json()['id']
    deviceId=request.get_json()['deviceId']
    userId=request.get_json()['userId']
    location=request.get_json()['location']
    control=request.get_json()['control']
    availablelbs=request.get_json()['availablelbs']

    cur.execute("UPDATE device SET DeviceId ='"+ str(deviceId) +"' , UserId= (select Id from user where UserId = '"+str(userId)+"'), Location = '"+ str(location) +"', Control= '"+ str(control) +"', AvailableLbs= '"+ str(availablelbs) +"' WHERE Id = '"+ str(id) +"'")
    mysql.connection.commit()

    result ={
     "id":id,
     "deviceId":deviceId,
     "userId":userId,
     "location":location,
     "availablelbs":availablelbs,
     "control": control
    }
    return jsonify({"result":result}, 200)


@app.route('/home/chartData',methods=['GET'])
def chartData():
    cur=mysql.connection.cursor()    
    cur.execute("SELECT s.DeviceDateTime, s.CreditAmount, s.VendLbs FROM stock as s")

    res = cur.fetchall()    
    stockDataResp = []

    '''jsonify({"Result":res})`indx``Date_time``merchantId``StoreId``TerminalId`,
     `TransactionId`, `Amount`, `PaymentStatus`, `VendStatus`, `Balance`
    else:
        return make_response(jsonify({"message": "Request body must be JSON"}), 400)'''

    for row in res:
        response_body = {
            "date_time": row['DeviceDateTime'],
            "amount": row['CreditAmount'],
            "vendlbs": row['VendLbs']
        }
        stockDataResp.append(response_body)

    result = make_response(jsonify(stockDataResp), 200)

    return result


@app.route('/home/emailAlert',methods=['PUT'])
def emailAlert():
    cur=mysql.connection.cursor()
    
    email1=request.get_json()['email1']
    email2=request.get_json()['email2']
    email3=request.get_json()['email3']
    
    cur.execute("UPDATE alert SET Email='"+ str(email1) +"' WHERE Id = '"+ str(1) +"'")
    mysql.connection.commit()

    cur.execute("UPDATE alert SET Email='"+ str(email2) +"' WHERE Id = '"+ str(2) +"'")
    mysql.connection.commit()

    cur.execute("UPDATE alert SET Email='"+ str(email3) +"' WHERE Id = '"+ str(3) +"'")
    mysql.connection.commit()

    result ={
     "email1":email1,
     "email2":email2,
     "email3":email3
    }
    return jsonify({"result":result}, 200)


@app.route('/home/numberAlert',methods=['PUT'])
def numberAlert():
    cur=mysql.connection.cursor()
    
    number1=request.get_json()['number1']
    number2=request.get_json()['number2']
    number3=request.get_json()['number3']

    cur.execute("UPDATE alert SET Number='"+ str(number1) +"' WHERE Id = 1")
    mysql.connection.commit()

    cur.execute("UPDATE alert SET Number='"+ str(number2) +"' WHERE Id = 2")
    mysql.connection.commit()

    cur.execute("UPDATE alert SET Number='"+ str(number3) +"' WHERE Id = 3")
    mysql.connection.commit()

    result ={
     "number1":number1,
     "number2":number2,
     "number3":number3
    }
    return jsonify({"result":result}, 200)


@app.route('/home/alertData',methods=['GET'])
def alertData():
    cur=mysql.connection.cursor()    
    cur.execute("SELECT a.Email, a.Number FROM alert as a")

    res = cur.fetchall()    
    stockDataResp = []

    '''jsonify({"Result":res})`indx``Date_time``merchantId``StoreId``TerminalId`,
     `TransactionId`, `Amount`, `PaymentStatus`, `VendStatus`, `Balance`
    else:
        return make_response(jsonify({"message": "Request body must be JSON"}), 400)'''

    for row in res:
        response_body = {
            "email": row['Email'],
            "number": row['Number']
        }
        stockDataResp.append(response_body)

    result = make_response(jsonify(stockDataResp), 200)

    return result


@app.route('/device/scan',methods=['POST'])
def scan():
    cur=mysql.connection.cursor()

    deviceId=request.get_json()['DvcId']
    userId=request.get_json()['UsrId']
    amount=request.get_json()['CAmount']
    availablelbs=request.get_json()['Albs']

    cur.execute("INSERT INTO stock(DeviceId, UserId, CreditAmount, AvailableLbs) VALUES ('"+str(deviceId)+"', (select Id from user where UserId = '"+str(userId)+"') ,'"+str(amount)+"','"+str(availablelbs)+"')")

    mysql.connection.commit()

    result = ""
    cur.execute("SELECT max(Id) as Id FROM stock")
    rv=cur.fetchone()

    result ={
        "id":rv['Id'],
        "SerSettingF": 0,
	    "status":"sucsessfull"
    }
    return jsonify(result)


@app.route('/device/vendingSuccess',methods=['POST'])
def vendingSuccess():
    cur=mysql.connection.cursor()

    result = ""

    id=request.get_json()['Id']
    # deviceId=request.get_json()['DvcId']
    # userId=request.get_json()['UsrId']
    amount=request.get_json()['CAmount']
    debitAmount=request.get_json()['DAmount']
    availablelbs=request.get_json()['Albs']
    vendlbs=request.get_json()['Rlbs']

    cur.execute("UPDATE stock SET CreditAmount = '"+ str(amount) +"', DebitAmount= '"+ str(debitAmount) +"', VendLbs= '"+ str(vendlbs) +"', AvailableLbs= '"+ str(availablelbs) +"' WHERE Id = '"+ str(id) +"'")
    mysql.connection.commit()

    result ={
        "SerSettingF": 0,
		"status":"successful"
    }
    return jsonify(result)


@app.route('/device/vendingFailed',methods=['POST'])
def vendingFailed():
    cur=mysql.connection.cursor()

    result = ""

    id=request.get_json()['Id']
    # deviceId=request.get_json()['DvcId']
    # userId=request.get_json()['UsrId']
    amount=request.get_json()['CAmount']
    debitAmount=request.get_json()['DAmount']
    availablelbs=request.get_json()['Albs']
    vendlbs=request.get_json()['Rlbs']

    cur.execute("UPDATE stock SET CreditAmount = '"+ str(amount) +"', DebitAmount= '"+ str(debitAmount) +"', VendLbs= '"+ str(vendlbs) +"', AvailableLbs= '"+ str(availablelbs) +"' WHERE Id = '"+ str(id) +"'")
    mysql.connection.commit()

    result = {
        "SerSettingF": 0,
        "status" : "successful"
    }
    return jsonify(result)



@app.route('/device/sync',methods=['POST'])
def sync():
    cur=mysql.connection.cursor()

    #id=request.get_json()['Id']
    deviceId=request.get_json()['DvcId']
    # userId=request.get_json()['UsrId']
    warning=request.get_json()['W_F']
    doorLeft=request.get_json()['L_D']
    doorRight=request.get_json()['R_D']
    warninglbs=request.get_json()['Wlbs']
    #availablelbs=request.get_json()['Albs']
    tempType=request.get_json()['T_t']
    vendTime=request.get_json()['V_T']
    priceLbs=request.get_json()['Prc']
    flag=request.get_json()['Up_F']
    print("flag")
    print(flag)
    rv = ""
    result = ""

    if warning == "1" :
        cur=mysql.connection.cursor()    
        cur.execute("SELECT a.Email FROM alert as a")

        emailResp = cur.fetchall()    
        emailDataResp = []

        for row in emailResp:
            if row['Email'] != '':
                emailDataResp.append(row['Email'])
                msg = Message('FireWood Twilio Test Email', recipients=[row['Email']])
                msg.body = ('Congratulations! You have sent a test email with '
                            'FireWood Twilio!')
                msg.html = ('<h1>FireWood Twilio Test Email</h1>'
                            '<p>Congratulations! You have sent a test email with '
                            '<b>FireWood Twilio</b>!</p>')
                mail.send(msg)

        print(emailDataResp)


    if flag == 1 :
        print("---------")
        cur.execute("UPDATE devicesetting SET WarningLbs= '"+ str(warninglbs) +"', LeftDoor= '"+ str(doorLeft) +"', RightDoor= '"+ str(doorRight) +"', Temperature= '"+ str(tempType) +"', VendTime= '"+ str(vendTime) +"',LbsPrice=  '"+ str(priceLbs) +"', Flag= \"0\" WHERE DeviceId = '"+ str(deviceId) +"'")
        mysql.connection.commit()
        result ={
            "SerSettingF": 0,
		    "status":"successful"
        }
    else :
        cur.execute("SELECT Flag FROM devicesetting WHERE DeviceId = '"+ str(deviceId) +"'")
        rv = cur.fetchone()

        print("Inside if condition")
        print(rv['Flag'])
        if rv['Flag'] == 1 :
            cur.execute("SELECT WarningLbs, Temperature, VendTime, LbsPrice FROM devicesetting WHERE DeviceId = '"+ str(deviceId) +"'")
            res = cur.fetchone()

            cur.execute("SELECT Control FROM device WHERE DeviceId = '"+ str(deviceId) +"'")
            deviceRes = cur.fetchone()

           

            result = {
                "SerSettingF": 1,
			    "status":"successful",
                "settings" : {
                    "Wlbs":res['WarningLbs'],
                    "T_t":res['Temperature'], 
                    "V_t":res['VendTime'],
                    "Prc":res['LbsPrice'],
                    "Actv":deviceRes['Control']
                }
            
            } 
            print(res['WarningLbs'])
        else:

            result = {
                "SerSettingF": 0,
		        "status":"successful"
            }

    return jsonify(result)



@app.route('/home/setting',methods=['GET'])
def setting():
    cur=mysql.connection.cursor()    
    cur.execute("SELECT s.Id, s.DeviceId, u.UserId, s.WarningLbs, s.LeftDoor, s.RightDoor, s.Temperature, s.VendTime, s.LbsPrice FROM devicesetting as s JOIN user as u ON u.Id = s.UserId")

    res = cur.fetchall()    
    settingRes = []
    
    '''jsonify({"Result":res})`indx``Date_time``merchantId``StoreId``TerminalId`,
     `TransactionId`, `Amount`, `PaymentStatus`, `VendStatus`, `Balance`
    else:
        return make_response(jsonify({"message": "Request body must be JSON"}), 400)'''

    for row in res:
        response_body = {
            "id": row['Id'],
            "deviceId": row['DeviceId'],
            "userId": row['UserId'],
            "warningLbs": row['WarningLbs'],
            "leftDoor": row['LeftDoor'],
            "rightDoor": row['RightDoor'],
            "temperature": row['Temperature'],
            "vendTime": row['VendTime'],
            "lbsPrice": row['LbsPrice']
        }
        settingRes.append(response_body)

    result = make_response(jsonify(settingRes), 200)

    return result


@app.route('/home/userSetting',methods=['POST'])
def userSetting():
    cur=mysql.connection.cursor()
    userId=request.get_json()['userId']

    cur.execute("SELECT s.Id, s.DeviceId, u.UserId, s.WarningLbs, s.LeftDoor, s.RightDoor, s.Temperature, s.VendTime, s.LbsPrice FROM devicesetting as s JOIN user as u ON u.Id = s.UserId where u.UserId='"+str(userId)+"'")

    res = cur.fetchall()    
    settingRes = []
    
    '''jsonify({"Result":res})`indx``Date_time``merchantId``StoreId``TerminalId`,
     `TransactionId`, `Amount`, `PaymentStatus`, `VendStatus`, `Balance`
    else:
        return make_response(jsonify({"message": "Request body must be JSON"}), 400)'''

    for row in res:
        response_body = {
            "id": row['Id'],
            "deviceId": row['DeviceId'],
            "userId": row['UserId'],
            "warningLbs": row['WarningLbs'],
            "leftDoor": row['LeftDoor'],
            "rightDoor": row['RightDoor'],
            "temperature": row['Temperature'],
            "vendTime": row['VendTime'],
            "lbsPrice": row['LbsPrice']
        }
        settingRes.append(response_body)

    result = make_response(jsonify(settingRes), 200)

    return result

@app.route('/home/updateSetting',methods=['PUT'])
def updateSetting():
    cur=mysql.connection.cursor()

    id=request.get_json()['id']
    warningLbs=request.get_json()['warningLbs']
    temperature=request.get_json()['temperature']
    vendTime=request.get_json()['vendTime']
    lbsPrice=request.get_json()['lbsPrice']

    cur.execute("UPDATE devicesetting SET WarningLbs ='"+ str(warningLbs) +"' , Temperature = '"+ str(temperature) +"', VendTime= '"+ str(vendTime) +"', LbsPrice= '"+ str(lbsPrice) +"' , Flag='1' WHERE Id = '"+ str(id) +"'")
    mysql.connection.commit()

    result ={
     "id":id,
     "warningLbs":warningLbs,
     "temperature":temperature,
     "vendTime":vendTime,
     "lbsPrice":lbsPrice
    }
    return jsonify({"result":result}, 200)


# message object mapped to a particular URL ‘/’ 
@app.route('/device/sentAlert',methods=['GET'])
def sentAlert(): 
    cur=mysql.connection.cursor()    
    cur.execute("SELECT a.Email FROM alert as a")

    emailResp = cur.fetchall()    
    emailDataResp = []

    for row in emailResp:
        if row['Email'] != '':
            emailDataResp.append(row['Email'])

    print(emailDataResp)
    # print(emailDataResp[0])
    # print(emailDataResp[1])
    # print(emailDataResp[2])

    msg = Message('FireWood Twilio Test Email', recipients=emailDataResp)
    msg.body = ('Congratulations! You have sent a test email with '
                'FireWood Twilio!')
    msg.html = ('<h1>FireWood Twilio Test Email</h1>'
                '<p>Congratulations! You have sent a test email with '
                '<b>FireWood Twilio</b>!</p>')
    mail.send(msg)

    return 'Sent'


# @app.route('/', methods=['GET', 'POST'])
# def index():
#     if request.method == 'POST':
#         recipient = request.form['recipient']
#         msg = Message('Twilio SendGrid Test Email', recipients=[recipient])
#         msg.body = ('Congratulations! You have sent a test email with '
#                     'Twilio SendGrid!')
#         msg.html = ('<h1>Twilio SendGrid Test Email</h1>'
#                     '<p>Congratulations! You have sent a test email with '
#                     '<b>Twilio SendGrid</b>!</p>')
#         mail.send(msg)
#         flash(f'A test message was sent to {recipient}.')
#         return redirect(url_for('index'))
#     return render_template('index.html')


# if __name__ == '__main__': 
#    app.run(debug = True) 
if(__name__=='__main__'):
    app.run(host='192.168.0.127',debug=True,port=5000)