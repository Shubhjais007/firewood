import React, { Component } from 'react';
import {Container, Box, Typography, TextField, Button, LinearProgress } from '@material-ui/core';
import axios from 'axios';

export class EmailAlertFragments extends Component {
    constructor() {
      super()
    
      this.state = {
        email1:"",
        email2:"",
        email3:"",
        email1_error:null,
        email2_error:null,
        email3_error:null,
        show_progress: false,
        show_sucess: false,
      };
      
      this.handleChange = this.handleChange.bind()
      this.setEmailAlert = this.setEmailAlert.bind()

    };

    componentDidMount(){  
        var Email = [];
        axios.get('/home/alertData').then((res) => {
            
            var dataResp = res.data;

            for (var dataObj of dataResp)
            {
                Email.push(dataObj.email);
            }
            this.setState(
                { 
                    email1:Email[0],
                    email2:Email[1],
                    email3:Email[2]
                });
        });
    }
   
    handleChange = (e) => {
        this.setState({
            [e.target.name]:e.target.value
        })
    }

    setEmailAlert = (e) => {
        let data_valid = true;
               
        this.setState({
            email1_error:null,
            email2_error:null,
            email3_error:null,
        })
        if(this.state.email1 === "" && this.state.email2 === "" && this.state.email3 === ""){
            this.setState({
                email1_error:"Required!",
                email2_error:"Required!",
                email3_error:"Required!"
            })
            data_valid=false;
        }
        // if(this.state.email2 === ""){
        //     this.setState({
        //         email2_error:"Required!"
        //     })
        //     data_valid=false;
        // } 
        // if(this.state.email3 === ""){
        //     this.setState({
        //         email3_error:"Required!"
        //     })
        //     data_valid=false;
        // }
        if(data_valid){
            this.setState({                
                show_progress: true
            })
        }
        if(data_valid){

            e.preventDefault()
            console.log("Email Alert Set !!")
            axios
            .put('/home/emailAlert', {
                email1: this.state.email1 ,
                email2: this.state.email2 ,
                email3: this.state.email3 
            })
            .then(response => {
                this.setState({     
                    show_sucess: true,
                    show_progress: false
                })
                console.log('Alert Email Set Successfully !!')
            })                        
        }
        this.setState({
            update:true
        }) 
    }


    render() {
        return (
            <Container maxWidth="xs">
                <Box bgcolor="#fafafa" boxShadow="3" borderRadius="12px" align='center' p='24px' mt="30px">                    
                    <Typography varient="h5" color="textSecondary">
                        Set Email Alert
                    </Typography>
                    <TextField name='email1' onChange={this.handleChange} error={this.state.email1_error != null} helperText={this.state.email1_error} label="Email Id" id="emailId1" value= {this.state.email1} type="text" fullWidth={true} size="small" margin="normal"/>
                    <TextField name='email2'  onChange={this.handleChange} error={this.state.email2_error != null} helperText={this.state.email2_error} label="Email Id" id="emailId2" type="text"   value= {this.state.email2} fullWidth={true} size="small" margin="normal"/>                    
                    <TextField name='email3' onChange={this.handleChange} error={this.state.email3_error != null} helperText={this.state.email3_error} label="Email Id" id="emailId3" type="text"  value= {this.state.email3} fullWidth={true} size="small" margin="normal"/>
                    <br/>
                    <br/>
                    <Button variant="contained" onClick={this.setEmailAlert} size="large" color="primary" margin="normal" fullWidth={true}>
                        Set Alert
                    </Button>
                    <br/>
                    <br/>
                    {
                        this.state.show_sucess?
                        <Typography varient="h4" color="primary">Email Alert Set Sucessfully !! </Typography>
                        :null
                    }
                    {
                        this.state.show_progress?
                        <LinearProgress color="primary" />
                        :null
                    }
                                        
                </Box>
            </Container>
        )
    }
}

export default EmailAlertFragments
