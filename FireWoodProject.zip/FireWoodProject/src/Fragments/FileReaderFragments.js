import React, { Component } from 'react';
import Papa from 'papaparse';
//import {Container, Box, Typography, TextField, Button, LinearProgress } from '@material-ui/core';
import {Container, Box, Typography, Button } from '@material-ui/core';
//import {firebaseAuth} from '../firebase';
import axios from 'axios';
//import { Box } from '@material-ui/core';

export class FileReaderFragments extends Component {
    constructor() {
      super();
      this.state = {
        csvfile: undefined
      };
      this.updateData = this.updateData.bind(this);
    }
  
    handleChange = event => {
      this.setState({
        csvfile: event.target.files[0]
      });
    };
  
    importCSV = () => {
      const { csvfile } = this.state;
      Papa.parse(csvfile, {
        complete: this.updateData,
        header: true
      });
    };
  
    updateData(result) {
      var data = result.data;
      axios
      .post('/home/fileUpload', data)
      .then(response => {
          console.log('CSV Data sent Sucessfully !!');
          console.log(response);
          console.log(data);
      });      
    }
  
    render() {
      console.log(this.state.csvfile);
      return (
        <Container maxWidth="ms">
          <Box bgcolor="#fafafa" boxShadow="3" borderRadius="12px" align='center' p='24px' mt="60px">  
            <Typography variant="h4">Import CSV File!</Typography> 
            <br/>
            <br/>
            <input
              className="csv-input"
              type="file"
              ref={input => {
                this.filesInput = input;
              }}
              name="file"
              placeholder={null}
              onChange={this.handleChange}
            />
            <p />
            <Button variant="contained" onClick={this.importCSV} size="medium" color="primary" margin="normal" > Upload Now</Button>
            
          </Box>
        </Container>
      );
    }
  }
  
  export default FileReaderFragments;