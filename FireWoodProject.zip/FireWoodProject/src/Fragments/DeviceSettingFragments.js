import React, { Component } from 'react';
//import ReactDOM from 'react-dom';
import MaterialTable from 'material-table';
import { AddBox, ArrowDownward } from "@material-ui/icons";
import { forwardRef } from 'react';
//import {Box, Container} from '@material-ui/core';
//import Switch from '@material-ui/core/Switch';

import axios from 'axios';

//import AddBox from '@material-ui/icons/AddBox';
//import ArrowDownward from '@material-ui/icons/ArrowDownward';
import Check from '@material-ui/icons/Check';
import ChevronLeft from '@material-ui/icons/ChevronLeft';
import ChevronRight from '@material-ui/icons/ChevronRight'; 
import Clear from '@material-ui/icons/Clear';
import DeleteOutline from '@material-ui/icons/DeleteOutline';
import Edit from '@material-ui/icons/Edit';
import FilterList from '@material-ui/icons/FilterList';
import FirstPage from '@material-ui/icons/FirstPage';
import LastPage from '@material-ui/icons/LastPage';
import Remove from '@material-ui/icons/Remove';
import SaveAlt from '@material-ui/icons/SaveAlt';
import Search from '@material-ui/icons/Search';
import ViewColumn from '@material-ui/icons/ViewColumn';


const tableIcons = {
    Add: forwardRef((props, ref) => <AddBox {...props} ref={ref} />),
    Check: forwardRef((props, ref) => <Check {...props} ref={ref} />),
    Clear: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
    Delete: forwardRef((props, ref) => <DeleteOutline {...props} ref={ref} />),
    DetailPanel: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
    Edit: forwardRef((props, ref) => <Edit {...props} ref={ref} />),
    Export: forwardRef((props, ref) => <SaveAlt {...props} ref={ref} />),
    Filter: forwardRef((props, ref) => <FilterList {...props} ref={ref} />),
    FirstPage: forwardRef((props, ref) => <FirstPage {...props} ref={ref} />),
    LastPage: forwardRef((props, ref) => <LastPage {...props} ref={ref} />),
    NextPage: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
    PreviousPage: forwardRef((props, ref) => <ChevronLeft {...props} ref={ref} />),
    ResetSearch: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
    Search: forwardRef((props, ref) => <Search {...props} ref={ref} />),
    SortArrow: forwardRef((props, ref) => <ArrowDownward {...props} ref={ref} />),
    ThirdStateCheck: forwardRef((props, ref) => <Remove {...props} ref={ref} />),
    ViewColumn: forwardRef((props, ref) => <ViewColumn {...props} ref={ref} />)
  };



export class DeviceSettingFragments extends Component {
  constructor(props) {
    super(props)
  
    this.state = {
      columns: [ 
        { title: 'Id', field: 'id', hidden: true },
        { title: 'Device ID', field: 'deviceId', editable: false},
        { title: 'User ID', field: 'userId', editable: false},
        { title: 'Warning Lbs', field: 'warningLbs'},
        { title: 'Left Door', field: 'leftDoor' , lookup: { 1: 'Open', 0: 'Close' }, editable: false},
        { title: 'Right Door', field: 'rightDoor' , lookup: {1: 'Open', 0: 'Close'}, editable: false},
        { title: 'Temperature Type', field: 'temperature' , lookup: {1: '°C', 0: '°F'}},
        { title: 'Vend Time', field: 'vendTime' , lookup: {5: '5 min', 10: '10 min', 15:'15 min', 20:'20 min'}},
        { title: 'Price/Lbs', field: 'lbsPrice' },
      ],
      data: [],
      user : JSON.parse(localStorage.getItem('user')),
    };
  };
  
  //axios.get(EMPLOYEE_API_BASE_URL)
  componentDidMount(){
    
    let checkRole = (this.state.user !== null ? this.state.user.role : null);
    let userName = (this.state.user !== null ? this.state.user.userId : null);
    if(checkRole !== "admin"){
      axios.post('/home/userSetting', {userId : userName}).then((res) => {
        this.setState({ data: res.data});
      });
    }
    else{
      axios.get('/home/setting').then((res) => {
        this.setState({ data: res.data});
    });
    }    
  }

  render() {
    return (
      <MaterialTable
      title="Device Settings Panel"
      columns={this.state.columns}
      data={this.state.data}
      icons={tableIcons}
      editable={{
        onRowUpdate: (newData, oldData) =>
          new Promise((resolve) => {
            setTimeout(() => {
              resolve();
              if (oldData) {
                this.setState((prevState) => {
                  const data = [...prevState.data];
                  data[data.indexOf(oldData)] = newData;
                  return { ...prevState, data };
                });
                console.log(newData);
                console.log(newData.id);
                console.log(newData.terminalId);
                console.log(newData.deviceStatus);
                axios.put('/home/updateSetting', {id : newData.id, warningLbs: newData.warningLbs, temperature: newData.temperature, vendTime: newData.vendTime, lbsPrice: newData.lbsPrice}).then((res) => {
                  console.log('Device Setting Updated Sucessfully !!');
                  console.log(res);       
                  this.setState({ statusUpdate: true});           
                });
              }
            }, 600);
          }),
      }}
      options={{
        columnsButton: true,
        exportAllData: false,
        exportButton: true,
        pageSize: 20,
        pageSizeOptions: [20, 50, 100],
        sorting: true,
      }}      
    />
    )
  }
}

export default DeviceSettingFragments;
