import React, { Component } from 'react';
import {Container, Box, Typography, TextField, Button, LinearProgress } from '@material-ui/core';
//import logo from '../Media/embalogo.png'; 

import logo from '../Media/FirewoodLogo.png';
//import Dashboard from '../Pages/Dashboard';

//API login
import axios from 'axios';
import jwt_decode from 'jwt-decode';
//firebase Authentication
//import {firebaseAuth, firestore} from '../firebase';
import {firebaseAuth} from '../firebase';
//import { blue } from '@material-ui/core/colors';


//import {} from '@material-ui/core/colors';


class Login extends Component {
    
    constructor(props) {
        super(props)
    
        this.state = {
             user:"",
             password:"",
             user_error:null,
             password_error:null,
             show_progress: false,
        };

        this.handleChange = this.handleChange.bind()
        this.login = this.login.bind()
    }

    handleChange = (e) => {
        this.setState({
            [e.target.name]:e.target.value
        })

    }

    login = (e) => {
        let data_valid = true;
        
        this.setState({
             user_error:null,
             password_error:null,
        })
        
        if(this.state.user === ""){
            this.setState({
                user_error:"Required!"
            })
            data_valid=false;
        }
        if(this.state.password === ""){            
            this.setState({
                password_error:"Required!"
            })
            data_valid=false;
        }
        if(data_valid){
            this.setState({                
                show_progress: true
            })
        }
        if(data_valid){            
            e.preventDefault();
            axios
            .post('/user/login', {
            userId: this.state.user,
            password: this.state.password
            })
            .then(response => {
                // if (!res.error) {
                //     this.props.history.push(`/profile`)
                //   }
                const token = response.data.token;
                const user = jwt_decode(token);
                localStorage.setItem('usertoken', token);
                localStorage.setItem('user', JSON.stringify(user.identity));
                console.log(token);
                console.log(user.identity);
            });
        }

        if(data_valid){
           
            e.preventDefault();
            const email = this.state.user + '@embatronix.com';
            const password = this.state.password;

            firebaseAuth
            .signInWithEmailAndPassword(email, password)
            .then((res) => {                   
                this.props.history.replace("/AdminDashboard");
            })
            .catch((err) => {
                console.log(err.code); 
                if(err.code==="auth/wrong-password"){
                    this.setState({   
                        password_error:"Worng Password !!",           
                        show_progress: false
                    });
                }
                else if(err.code==="auth/user-not-found") {
                    this.setState({   
                        user_error:"UserId not found !!",           
                        show_progress: false
                    });
                }
                else if(err.code==="auth/network-request-failed") {
                    this.setState({   
                        password_error:"Network Error !!",           
                        show_progress: false
                    });
                }
            })
            
        }
        this.setState({
            update:true
        })        
    }

    render() {
        return (
            <Container maxWidth="xs">
                <Box bgcolor="#fafafa" boxShadow="3" borderRadius="12px" align='center' p='24px' mt="120px">
                    <img src={logo} height="90px" width="150px" alt="logo"/>                    
                    <Typography varient="h2" color="textSecondary">
                        Admin Login
                    </Typography>
                    <TextField name='user' onChange={this.handleChange}  error={this.state.user_error != null} helperText={this.state.user_error} label="User Id" id="user-Id" type="text" fullWidth={true} size="small" margin="normal"/>
                    <TextField name='password' onChange={this.handleChange} error={this.state.password_error != null} helperText={this.state.password_error} label="Password" id="password" type="password" fullWidth={true} size="small" margin="normal"/>
                    <br/>
                    <br/>
                    <Button variant="contained"  onClick={this.login} size="large" color="primary" margin="normal" fullWidth={true}>
                        Login
                    </Button>
                    <br/>
                    <br/>
                    {
                        this.state.show_progress?
                        <LinearProgress color="primary" />
                        :null
                    }
                    
                    
                </Box>
            </Container>
        );
    }
}

export default Login;
