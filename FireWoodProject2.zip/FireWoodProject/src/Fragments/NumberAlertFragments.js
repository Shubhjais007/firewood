import React, { Component } from 'react';
import {Container, Box, Typography, TextField, Button, LinearProgress } from '@material-ui/core';
import axios from 'axios';

export class NumberAlertFragments extends Component {
    constructor() {
      super()
    
      this.state = {
        number1:"",
        number2:"",
        number3:"",
        number1_error:null,
        number2_error:null,
        number3_error:null,
        show_progress: false,
        show_sucess: false,
      };
      
      this.handleChange = this.handleChange.bind()
      this.setNumberAlert = this.setNumberAlert.bind()

    };
   

    componentDidMount(){
        var Number = [];
        axios.get('/home/alertData').then((res) => {
            
            var dataResp = res.data;

            for (var dataObj of dataResp)
            {
                Number.push(dataObj.number);
            }
            this.setState(
                { 
                    number1:Number[0],
                    number2:Number[1],
                    number3:Number[2]
                });
        });
    }


    handleChange = (e) => {
        this.setState({
            [e.target.name]:e.target.value
        })
    }

    setNumberAlert = (e) => {
        let data_valid = true;
               
        this.setState({
            number1_error:null,
            number2_error:null,
            number3_error:null,
        })
        if(this.state.number1 === "" && this.state.number2 === "" && this.state.number3 === ""){
            this.setState({
                number1_error:"Required!",
                number2_error:"Required!",
                number3_error:"Required!"
            })
            data_valid=false;
        }
        // if(this.state.number2 === ""){
        //     this.setState({
        //         number2_error:"Required!"
        //     })
        //     data_valid=false;
        // }
        // if(this.state.number3 === ""){
        //     this.setState({
        //         number3_error:"Required!"
        //     })
        //     data_valid=false;
        // }
        if(data_valid){
            this.setState({                
                show_progress: true
            })
        }
        if(data_valid){

            e.preventDefault()
            console.log("Set Number Alerts !!")
            axios
            .put('/home/numberAlert', {
                number1: this.state.number1 ,
                number2: this.state.number2 ,
                number3: this.state.number3 
            })
            .then(response => {
                this.setState({     
                    show_sucess: true,
                    show_progress: false
                })
                console.log('Number Alert Set Sucessfully !!')
            })            
        }
        this.setState({
            update:true
        }) 
    }


    render() {
        return (
            <Container maxWidth="xs">
                <Box bgcolor="#fafafa" boxShadow="3" borderRadius="12px" align='center' p='24px' mt="30px">                    
                    <Typography varient="h5" color="textSecondary">
                        Set Number Alert
                    </Typography>
                    <TextField name='number1' onChange={this.handleChange} error={this.state.number1_error != null} helperText={this.state.number1_error} value= {this.state.number1} label="Contact Number" id="numberId1" type="text" fullWidth={true} size="small" margin="normal"/>
                    <TextField name='number2'  onChange={this.handleChange} error={this.state.number2_error != null} helperText={this.state.number2_error} value= {this.state.number2} label="Contact Number" id="numberId2" type="text" fullWidth={true} size="small" margin="normal"/>                    
                    <TextField name='number3' onChange={this.handleChange} error={this.state.number3_error != null} helperText={this.state.number3_error} value= {this.state.number3} label="Contact Number" id="numberId3" type="text" fullWidth={true} size="small" margin="normal"/>
                    <br/>
                    <br/>
                    <Button variant="contained" onClick={this.setNumberAlert} size="large" color="primary" margin="normal" fullWidth={true}>
                        Set Alert
                    </Button>
                    <br/>
                    <br/>
                    {
                        this.state.show_sucess?
                        <Typography varient="h4" color="primary"> Number Alert Set Sucessfully !! </Typography>
                        :null
                    }
                    {
                        this.state.show_progress?
                        <LinearProgress color="primary" />
                        :null
                    }
                                        
                </Box>
            </Container>
        )
    }
}

export default NumberAlertFragments
