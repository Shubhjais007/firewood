import React, { Component } from 'react';
import {Container, Box, Typography, TextField, Button, LinearProgress } from '@material-ui/core';
import axios from 'axios';

export class AddDeviceFragments extends Component {
    constructor() {
      super()
    
      this.state = {
        deviceId:"",
        userId:"",
        location:"",
        control:"",
        availablelbs:"",
        deviceId_error:null,
        userId_error:null,
        location_error:null,
        control_error:null,
        availablelbs_error:null,
        show_progress: false,
        show_sucess: false,
      };
      
      this.handleChange = this.handleChange.bind()
      this.addDevice = this.addDevice.bind()

    };
   
    handleChange = (e) => {
        this.setState({
            [e.target.name]:e.target.value
        })
    }

    addDevice = (e) => {
        let data_valid = true;
        
        this.setState({
            merchantId_error:null,
            userId_error:null,
            location_error:null,
            control_error:null,
        })
        if(this.state.deviceId === ""){
            this.setState({
                deviceId_error:"Required!"
            })
            data_valid=false;
        }
        if(this.state.userId === ""){            
            this.setState({
                userId_error:"Required!"
            })
            data_valid=false;
        }
        if(this.state.location === ""){            
            this.setState({
                location_error:"Required!"
            })
            data_valid=false;
        }
        if(this.state.control === ""){
            this.setState({
                control_error:"Required!"
            })
            data_valid=false;
        }
        if(this.state.availablelbs === ""){
            this.setState({
                availablelbs_error:"Required!"
            })
            data_valid=false;
        }
        if(data_valid){
            this.setState({                
                show_progress: true
            })
        }
        if(data_valid){

            e.preventDefault()
            console.log("Device Added !!")
            axios
            .post('/home/addDevice', {
                deviceId: this.state.deviceId ,
                userId: this.state.userId ,
                location: this.state.location,
                control: this.state.control ,
                availablelbs: this.state.availablelbs, 
            })
            .then(response => {
                this.setState({     
                    show_sucess: true,
                    show_progress: false
                })
                console.log('Device Added Sucessfully !!')
            })
        }
        this.setState({
            update:true
        }) 
    }


    render() {
        return (
            <Container maxWidth="xs">
                <Box bgcolor="#fafafa" boxShadow="3" borderRadius="12px" align='center' p='24px' mt="30px">                    
                    <Typography varient="h5" color="textSecondary">
                        Add New Device
                    </Typography>
                    <TextField name='deviceId' onChange={this.handleChange} error={this.state.merchantId_error != null} helperText={this.state.merchantId_error} label="Device ID" id="deviceId" type="text" fullWidth={true} size="small" margin="normal"/>                    
                    <TextField name='userId' onChange={this.handleChange} error={this.state.userId_error != null} helperText={this.state.userId_error} label="User ID" id="userId" type="text" fullWidth={true} size="small" margin="normal"/>
                    <TextField name='location' onChange={this.handleChange} error={this.state.location_error != null} helperText={this.state.location_error} label="Location" id="location" type="text" fullWidth={true} size="small" margin="normal"/>
                    <TextField name='control'  onChange={this.handleChange} error={this.state.storeId_error != null} helperText={this.state.storeId_error} label="Device Status" id="status" type="text" fullWidth={true} size="small" margin="normal"/>                    
                    <TextField name='availablelbs' onChange={this.handleChange} error={this.state.terminalId_error != null} helperText={this.state.terminalId_error} label="Wood Stock(lbs)" id="availableLbs" type="text" fullWidth={true} size="small" margin="normal"/>
                    <br/>
                    <br/>
                    <Button variant="contained" onClick={this.addDevice} size="large" color="primary" margin="normal" fullWidth={true}>
                        Add Device
                    </Button>
                    <br/>
                    <br/>
                    {
                        this.state.show_sucess?
                        <Typography varient="h4" color="primary"> Device Added Sucessfully !! </Typography>
                        :null
                    }
                    {
                        this.state.show_progress?
                        <LinearProgress color="primary" />
                        :null
                    }
                                        
                </Box>
            </Container>
        )
    }
}

export default AddDeviceFragments
