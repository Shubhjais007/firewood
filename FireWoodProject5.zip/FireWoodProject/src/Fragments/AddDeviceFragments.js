import React, { Component } from 'react';
import {Container, Box, Typography, TextField, Button, LinearProgress,RadioGroup, Radio, FormControlLabel, Select, MenuItem } from '@material-ui/core';
import axios from 'axios';

export class AddDeviceFragments extends Component {
    constructor() {
      super()
    
      this.state = {
        deviceId:"",
        userId:"",
        userRoleId:"",
        location:"",
        control:"",
        gtv:0,
        availablelbs:"",
        deviceList:[],
        userList:[],
        deviceId_error:null,
        userId_error:null,
        location_error:null,
        control_error:null,
        availablelbs_error:null,
        show_progress: false,
        show_sucess: false,
      };
      
      this.handleChange = this.handleChange.bind()
      this.addDevice = this.addDevice.bind()

    };

    componentDidMount(){  
        
        axios.get('/home/allDeviceName').then((res) => {
            console.log(res.data);
            console.log(res.data[0]);
            this.setState({ 
                deviceList: res.data
             });
            });

            axios.get('/home/allUserName').then((res) => {
                console.log(res.data);
                console.log(res.data[0]);
                this.setState({ 
                    userList: res.data,
                    userId: res.data[0]
                 });
                });
    }

    handleChange = (e) => {
        this.setState({
            [e.target.name]:e.target.value
        })
    }

    addDevice = (e) => {
        let data_valid = true;
        console.log(this.state.deviceList.includes(this.state.deviceId.toLowerCase()));
        this.setState({
            deviceId_error:null,
            userId_error:null,
            location_error:null,
            control_error:null,
        })
        console.log("Inside the Device !!");
        console.log(this.state.deviceId.toLowerCase());
        console.log(this.state.userId);
        console.log(this.state.location);
        console.log(this.state.gtv);


        if(this.state.deviceId === ""){
            console.log("DeviceId");
            this.setState({
                deviceId_error:"Required!"
            })
            data_valid=false;
        }
        if(this.state.deviceList.includes(this.state.deviceId.toLowerCase())){
            console.log("DeviceId");
            this.setState({
                deviceId_error:"Device already present!"
            })
            data_valid=false;
        }
        if(this.state.userId === ""){         
            console.log("UserId");   
            this.setState({
                userId_error:"Required!"
            })
            data_valid=false;
        }
        if(this.state.location === ""){    
            console.log("location");        
            this.setState({
                location_error:"Required!"
            })
            data_valid=false;
        }
        if(this.state.gtv === ""){
            console.log("gtv");
            this.setState({
                control_error:"Required!"
            })
            data_valid=false;
        }
        if(data_valid){
            this.setState({                
                show_progress: true
            })
        }
        if(data_valid){

            e.preventDefault()
            console.log("Device Added !!")
            axios
            .put('/home/addDevice', {
                deviceId: this.state.deviceId.toLowerCase() ,
                userId: this.state.userId.toLowerCase() ,
                location: this.state.location,
                control: this.state.gtv
            })
            .then(response => {
                
                console.log('Device Added Sucessfully !!')
                this.setState({     
                    show_sucess: true,
                    show_progress: false
                })                
            })
            .catch(e => {
                console.log(e.msg);
            })
        }
        this.setState({
            update:true
        }) 
    }


    render() {
        return (
            <Container maxWidth="xs">
                <Box bgcolor="#fafafa" boxShadow="3" borderRadius="12px" align='center' p='24px' mt="30px">                    
                    <Typography varient="h5" color="textSecondary">
                        Add New Device
                    </Typography>
                    <br/>
                    <Typography varient="h6" color="Primary" align="left">
                        User Id
                    </Typography>
                    <Select
                    labelId="select-label"
                    id="device-user-id"
                    value={this.state.userId}
                    onChange={e => this.setState({userId:e.target.value})}
                    fullWidth={true}
                    size="small" 
                    margin="normal"
                    align="left"
                    >
                         {
                            this.state.userList.map((user, i) => (
                            <MenuItem key={i} value={user} >{user}</MenuItem>
                            ))
                        }
                    </Select>
                    <TextField name='deviceId' onChange={this.handleChange} error={this.state.deviceId_error != null} helperText={this.state.deviceId_error} label="Device ID" id="deviceId" type="text" fullWidth={true} size="small" margin="normal"/>                    
                    <TextField name='location' onChange={this.handleChange} error={this.state.location_error != null} helperText={this.state.location_error} label="Location" id="location" type="text" fullWidth={true} size="small" margin="normal"/>
                    <br/>
                    <br/>
                    <Typography varient="h6" color="textSecondary" align="left">
                        GTV Status
                    </Typography>
                    <RadioGroup row aria-label="gtvStatus" name="gtvStatus" id="gtv-Status" value={this.state.gtv} onChange={e => this.setState({gtv:e.target.value})} >
                        <FormControlLabel value={1} control={<Radio color="primary"/>} label="ON" />
                        <FormControlLabel value={0} control={<Radio color="primary"/>} label="OFF" />
                    </RadioGroup>
                    <br/>
                    <Button variant="contained" onClick={this.addDevice} size="large" color="primary" margin="normal" fullWidth={true}>
                        Add Device
                    </Button>
                    <br/>
                    <br/>
                    {
                        this.state.show_sucess?
                        <Typography varient="h4" color="primary"> Device Added Sucessfully !! </Typography>
                        :null
                    }
                    {
                        this.state.show_progress?
                        <LinearProgress color="primary" />
                        :null
                    }
                                        
                </Box>
            </Container>
        )
    }
}

export default AddDeviceFragments
