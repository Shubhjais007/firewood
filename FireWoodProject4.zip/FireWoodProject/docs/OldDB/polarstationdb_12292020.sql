-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 23, 2020 at 06:12 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.3.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `polarstationdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `alert`
--

CREATE TABLE `alert` (
  `Id` int(11) NOT NULL,
  `Email` varchar(500) DEFAULT NULL,
  `Number` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `alert`
--

INSERT INTO `alert` (`Id`, `Email`, `Number`) VALUES
(1, '', '+917889521865'),
(2, 'shubham032@gmail.com', ''),
(3, '', '+919988776655');

-- --------------------------------------------------------

--
-- Table structure for table `device`
--

CREATE TABLE `device` (
  `Id` int(11) NOT NULL,
  `DeviceId` varchar(32) DEFAULT NULL,
  `UserId` int(5) DEFAULT NULL,
  `Location` varchar(100) DEFAULT NULL,
  `Status` int(11) DEFAULT NULL,
  `Control` int(11) DEFAULT NULL,
  `AvailableLbs` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `device`
--

INSERT INTO `device` (`Id`, `DeviceId`, `UserId`, `Location`, `Status`, `Control`, `AvailableLbs`) VALUES
(1, 'device1', 2, 'Lucknow', 1, 0, 1000),
(2, 'device2', 3, 'Agara', 1, 1, 1000),
(3, 'device3', 2, 'Noida', 0, 1, 1000),
(4, 'device4', 2, 'Mumbai', 0, 1, 700),
(5, 'device5', 2, 'Patna', 1, 1, 3457),
(6, 'device6', 3, 'Greater Noida', 1, 1, 5467),
(7, 'device7', 2, 'Punjab', 0, 0, 400),
(8, 'device8', 2, 'Ambala', 0, 0, 6785),
(9, 'device9', 3, 'Bangalore', 0, 0, 3457),
(10, 'device10', 2, 'Bangalore', 1, 1, 5000),
(11, 'device11', 2, 'Chennai', 0, 1, 3457),
(12, 'device12', 3, 'Hydrabad', 1, 1, 3457),
(13, 'device13', 2, 'Amritsar', 1, 1, 6785),
(14, 'device14', 2, 'Goa', 1, 1, 6785),
(15, 'device15', 3, 'Goa', 1, 1, 10000),
(16, 'device16', 2, 'Allahbad', 1, 1, 10000),
(17, 'device17', 3, 'Kerla', 1, 1, 3457),
(18, 'device18', 3, 'Ranchi', 1, 1, 3457),
(19, 'device19', 2, 'Dhanbad', 1, 1, 98748),
(20, 'device20', 3, 'Bokaro', 1, 1, 10000),
(21, 'device21', 3, 'Cuttak', 1, 1, 6785),
(22, 'device22', 2, 'Kolkata', 1, 1, 10000),
(23, 'device23', 3, 'Kashmir', 1, 1, 3457),
(24, 'device24', 3, 'Gujrat', 1, 1, 3457),
(25, 'device25', 2, 'Ahmadabad', 1, 1, 6785),
(26, 'device26', 3, 'Chennai', 1, 1, 98748),
(27, 'device27', 3, 'Amritsar', 1, 1, 10000),
(28, 'device28', 2, 'Pune', 1, 1, 98748),
(29, 'device29', 3, 'Pune', 1, 1, 10000),
(30, 'device30', 3, 'Kolkata', 1, 1, 98748),
(31, 'device31', 4, 'Deoghar', 1, 1, 5700),
(32, 'device32', 4, 'Dumka', 1, 1, 7600),
(33, 'device33', 2, 'Dumka', 1, 0, 7600),
(34, 'Device34', 3, 'Deoghar', 0, 1, 5600),
(35, 'Device35', 2, 'Bangalore', 0, 1, 6700);

-- --------------------------------------------------------

--
-- Table structure for table `devicesetting`
--

CREATE TABLE `devicesetting` (
  `Id` int(11) NOT NULL,
  `DeviceId` varchar(32) NOT NULL,
  `UserId` int(5) NOT NULL,
  `WarningLbs` int(10) DEFAULT NULL,
  `LeftDoor` int(1) DEFAULT NULL,
  `RightDoor` int(1) DEFAULT NULL,
  `Temperature` int(1) DEFAULT NULL,
  `VendTime` int(2) DEFAULT NULL,
  `LbsPrice` float DEFAULT NULL,
  `Flag` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `devicesetting`
--

INSERT INTO `devicesetting` (`Id`, `DeviceId`, `UserId`, `WarningLbs`, `LeftDoor`, `RightDoor`, `Temperature`, `VendTime`, `LbsPrice`, `Flag`) VALUES
(1, 'device1', 2, 1000, 0, 0, 1, 5, 35.75, 0),
(2, 'device2', 3, 1000, 0, 0, 1, 5, 35.75, 0),
(3, 'device3', 2, 1000, 0, 0, 1, 5, 35.75, 0),
(4, 'device4', 2, 700, 0, 0, 1, 5, 35.75, 0),
(5, 'device5', 2, 3457, 0, 0, 1, 5, 35.75, 0),
(6, 'device6', 3, 5467, 0, 0, 1, 5, 35.75, 0),
(7, 'device7', 2, 400, 0, 0, 1, 5, 35.75, 0),
(8, 'device8', 2, 6785, 0, 0, 1, 5, 35.75, 0),
(9, 'device9', 3, 700, 0, 0, 1, 5, 35.75, 0),
(10, 'device10', 2, 2000, 0, 0, 1, 5, 35.75, 0),
(11, 'device11', 2, 100, 0, 0, 1, 5, 35.75, 0),
(12, 'device12', 3, 900, 0, 0, 1, 5, 37.45, 0),
(13, 'device13', 2, 100, 0, 0, 1, 5, 35.75, 0),
(14, 'device14', 2, 200, 0, 0, 1, 5, 35.75, 0),
(15, 'device15', 3, 340, 0, 0, 1, 5, 35.75, 0),
(16, 'device16', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `Id` int(11) NOT NULL,
  `DeviceId` varchar(32) DEFAULT NULL,
  `UserId` int(5) DEFAULT NULL,
  `CreditAmount` float DEFAULT NULL,
  `DebitAmount` float DEFAULT NULL,
  `VendLbs` int(10) DEFAULT NULL,
  `AvailableLbs` int(10) DEFAULT NULL,
  `DeviceDateTime` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`Id`, `DeviceId`, `UserId`, `CreditAmount`, `DebitAmount`, `VendLbs`, `AvailableLbs`, `DeviceDateTime`) VALUES
(1, 'device1', 2, 200.502, NULL, 20, 4000, '2020-11-06 12:26:08'),
(2, 'device2', 3, 1000.1, NULL, 100, 10000, '2020-11-06 12:26:08'),
(3, 'device3', 2, 200.502, NULL, 40, 1000, '2020-11-06 13:19:00'),
(4, 'device4', 2, 1000.1, NULL, 60, 700, '2020-11-06 13:19:00'),
(5, 'device5', 2, 5694.3, NULL, 80, 3457, '2020-11-06 13:19:00'),
(6, 'device6', 3, 1000.1, NULL, 16, 5467, '2020-11-06 13:19:00'),
(7, 'device7', 2, 200.1, NULL, 10, 400, '2020-11-06 13:19:00'),
(8, 'device8', 2, 1000.1, NULL, 100, 6785, '2020-11-06 13:19:00'),
(9, 'device9', 3, 5694.3, NULL, 100, 3457, '2020-11-06 13:19:00'),
(10, 'device10', 2, 2000, NULL, 70, 5000, '2020-11-06 13:19:00'),
(11, 'device11', 2, 765.6, NULL, 100, 3457, '2020-11-06 13:19:00'),
(12, 'device12', 3, 765.6, NULL, 100, 3457, '2020-11-06 13:19:00'),
(13, 'device13', 2, 5694.3, NULL, 10, 6785, '2020-11-06 13:19:00'),
(14, 'device14', 2, 1000.1, NULL, 100, 6785, '2020-11-06 13:19:00'),
(15, 'device15', 3, 1000.1, NULL, 60, 10000, '2020-11-06 13:19:00'),
(16, 'device16', 2, 345.6, NULL, 57, 10000, '2020-11-06 13:19:00'),
(17, 'device17', 3, 345.6, NULL, 75, 3457, '2020-11-06 13:19:00'),
(18, 'device18', 3, 1000.1, NULL, 60, 3457, '2020-11-06 13:19:00'),
(19, 'device19', 2, 5694.3, NULL, 10, 98748, '2020-11-06 13:19:00'),
(20, 'device20', 3, 765.6, NULL, 55, 10000, '2020-11-06 13:19:00'),
(21, 'device21', 3, 345.6, NULL, 100, 6785, '2020-11-06 13:19:00'),
(22, 'device22', 2, 1450.1, NULL, 587, 17645, '2020-11-06 13:51:16'),
(23, 'device23', 3, 1000.1, NULL, 100, 3457, '2020-11-06 13:19:00'),
(24, 'device24', 3, 765.6, NULL, 80, 3457, '2020-11-06 13:19:00'),
(25, 'device25', 2, 345.6, NULL, 100, 6785, '2020-11-06 13:50:12'),
(26, 'device26', 3, 345.6, NULL, 100, 98748, '2020-11-06 13:19:00'),
(27, 'device27', 3, 345.6, NULL, 80, 10000, '2020-11-06 13:19:00'),
(28, 'device28', 2, 765.6, NULL, 98, 98748, '2020-11-06 13:19:00'),
(29, 'device29', 3, 1000.1, NULL, 10, 10000, '2020-11-06 13:19:00'),
(30, 'device30', 3, 5694.3, NULL, 100, 98748, '2020-11-06 13:19:00'),
(31, 'device12', 3, 10, 30, 100, 9000, '2020-11-23 22:10:01'),
(32, 'device12', 3, 10, 30, 100, 9000, '2020-11-23 22:12:18'),
(33, 'device12', 3, 30, NULL, NULL, 1000, '2020-11-23 17:24:56'),
(34, 'device12', 3, 30, NULL, NULL, 1000, '2020-11-23 17:25:50'),
(35, 'device12', 3, 30, NULL, NULL, 1000, '2020-11-23 17:25:52'),
(36, 'device12', 3, 30, NULL, NULL, 1000, '2020-11-23 17:27:09'),
(37, 'device12', 3, 30, NULL, NULL, 1000, '2020-11-23 17:29:15'),
(38, 'device12', 3, 30, NULL, NULL, 1000, '2020-11-23 17:46:30');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `Id` int(5) NOT NULL,
  `UserId` varchar(100) NOT NULL,
  `Password` varchar(500) NOT NULL,
  `Role` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`Id`, `UserId`, `Password`, `Role`) VALUES
(1, 'admin', '$2b$12$o.BufthIIKHcQMCAlVD.NulKceqFTv65oHrDe6rgmSHLwSQ6bA.TC', 'admin'),
(2, 'munib123', '$2b$12$M7EN6bP/wxauYs1eOFg3c.yS90ygnk/gKJaHf4YHYBc.WlBLxLiu.', 'user'),
(3, 'suraj123', '$2b$12$WQf2.vDU62x9iF6JKf8GIe8/1rI3Z7g0nrXamn.oWFCPZwPxZ8V/m', 'user'),
(4, 'shubh032', '$2b$12$Kqd7TK2TI67Umv7xglo5vuvf5JGLcfTSXmD.qP4RsxffUbaqlKHZi', 'user'),
(5, 'shubh123', '$2b$12$JGKwPrgF02XmyJFK2RB2DewPjAMERpB/cZTxahDPoK2V10DLz74b.', 'admin'),
(6, 'shubh21', '$2b$12$dkZ4fJJIxgzOJiLdgTqXbuDfDlWP/0942slGaTLVfnsudP3PDrjwK', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alert`
--
ALTER TABLE `alert`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `device`
--
ALTER TABLE `device`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_Device_DeviceId` (`DeviceId`),
  ADD KEY `IX_Device_UserId` (`UserId`);

--
-- Indexes for table `devicesetting`
--
ALTER TABLE `devicesetting`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_DeviceSetting_DeviceId_Flag` (`DeviceId`,`Flag`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_UserId` (`UserId`),
  ADD KEY `IX_DeviceId` (`DeviceId`),
  ADD KEY `IX_DateTime` (`DeviceDateTime`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_User_UserId` (`UserId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alert`
--
ALTER TABLE `alert`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `device`
--
ALTER TABLE `device`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `devicesetting`
--
ALTER TABLE `devicesetting`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `Id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
