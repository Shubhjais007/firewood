
// Firebase App (the core Firebase SDK) is always required and
// must be listed before other Firebase SDKs
import * as firebase from "firebase/app";

// Add the Firebase services that you want to use
import "firebase/auth";
import "firebase/firestore";

var firebaseConfig = {
  apiKey: "AIzaSyDHiWt2UG9wGv19M-bIDwMurgqFJejjCiA",
  authDomain: "firewood-f84a3.firebaseapp.com",
  databaseURL: "https://firewood-f84a3.firebaseio.com",
  projectId: "firewood-f84a3",
  storageBucket: "firewood-f84a3.appspot.com",
  messagingSenderId: "920236932792",
  appId: "1:920236932792:web:6374628d71072ec05afe4d",
  measurementId: "G-556LYGRDKS"
};

  // Initialize Firebase
firebase.initializeApp(firebaseConfig);

export const firebaseAuth = firebase.auth();
export const firestore = firebase.firestore();

export default firebase;