import React, { useState } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Drawer from '@material-ui/core/Drawer';
import AppBar from '@material-ui/core/AppBar';
import CssBaseline from '@material-ui/core/CssBaseline';
import Toolbar from '@material-ui/core/Toolbar';
import List from '@material-ui/core/List';
import Typography from '@material-ui/core/Typography';
import Divider from '@material-ui/core/Divider';
import ListItem from '@material-ui/core/ListItem';
//import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
//Icons 
//import {HomeRounded, StoreRounded, SettingsRounded, ExitToAppRounded, PersonAddRounded, DeviceHubRounded } from '@material-ui/icons';
import {StoreRounded, AddAlertRounded, SettingsRounded, ExitToAppRounded, DeviceHubRounded, AddToQueueRounded } from '@material-ui/icons';
//import AssignmentRoundedIcon from '@material-ui/icons/AssignmentRounded';
//import AddToQueueRoundedIcon from '@material-ui/icons/AddToQueueRounded';
//import logo from '../Media/embalogo.png';
import logo from '../Media/FirewoodLogo.png';

//import GirdList Table
//import {EnhancedTable} from '../Components/Component/GridList';
//import HomeFragments from '../Fragments/HomeFragments';
import DeviceFragments from '../Fragments/DeviceFragments';
import StatusFragments from '../Fragments/StatusFragments';
import AddDeviceFragments from '../Fragments/AddDeviceFragments';
//import UserFragments from '../Fragments/UserFragments';
//import FileReaderFragments from '../Fragments/FileReaderFragments';
//import StockChartFragments from '../Fragments/StockChartFragments';
import SetAlertsFragments from '../Fragments/SetAlertsFragments';
import LineChartFragments from '../Fragments/LineChartFragments';
//import DashboardFragments from '../Fragments/DashboardFragments';
import HomeDashboardFragments from '../Fragments/HomeDashboardFragments';
import { firebaseAuth } from '../firebase';
import {Redirect} from 'react-router-dom';
const drawerWidth = 180;//240;

const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
  },
  appBar: {
    zIndex: theme.zIndex.drawer + 1,
  },
  drawer: {
    width: drawerWidth,
    flexShrink: 0,
  },
  drawerPaper: {
    width: drawerWidth,
  },
  drawerContainer: {
    overflow: 'auto',
  },
  content: {
    flexGrow: 1,
    padding: theme.spacing(3),
  },
}));


export default function ClippedDrawer() {
  
  let userData = JSON.parse(localStorage.getItem('user'));
  let checkRole = (userData !== null ? userData.role : "");
  const classes = useStyles();
  const [fragement, setfragment] = useState("Sales");
  
  const loadFragement = () => {
      switch(fragement) {
        case "Sales":
          return <HomeDashboardFragments/>;
        case "Charts":
          return <LineChartFragments/>;
        case "Device":
            return <DeviceFragments/>;
        case "MasterControl":
            return <StatusFragments/>;
        case "AddDevice":
            return <AddDeviceFragments/>;
        case "Alert":
            return <SetAlertsFragments/>;
        case "Logout":            
            firebaseAuth.signOut();
            localStorage.removeItem('user');
            localStorage.removeItem('selectedRow');
            localStorage.removeItem('usertoken');
            return <Redirect to='/login' />;            
        default:
            break;
      }
  }

  return (
    <div className={classes.root}>
      <CssBaseline />
      <AppBar position="fixed" className={classes.appBar}>
        <Toolbar>          
            <img src={logo} height="50px" width="100px" alt="logo" style={{marginRight:"0px"}}/>
            <Typography display="inline" variant="h4">Dashboard</Typography>            
        </Toolbar>
      </AppBar>
      <Drawer
        className={classes.drawer}
        variant="permanent"
        classes={{
          paper: classes.drawerPaper,
        }}
      >
        <Toolbar />
        <div className={classes.drawerContainer}>
          <List>            
            <ListItem button onClick={(e) => {setfragment("Sales")}}>
                <StoreRounded color="primary" style={{marginRight:"4px"}}/>
                <ListItemText primary={"Sales"} display="inline" />
            </ListItem>
            <ListItem button onClick={(e) => {setfragment("Charts")}}>
                <StoreRounded color="primary" style={{marginRight:"4px"}}/>
                <ListItemText primary={"Charts"} display="inline" />
            </ListItem>
            <ListItem button onClick={(e) => {setfragment("Device")}}>
                <DeviceHubRounded color="primary" style={{marginRight:"4px"}}/>
                <ListItemText primary={"Device"} display="inline"/>
            </ListItem>
            {
              checkRole === 'admin' ?
              <ListItem button onClick={(e) => {setfragment("MasterControl")}}>
                  <SettingsRounded color="primary" style={{marginRight:"4px"}}/>
                  <ListItemText primary={"Master Control"} display="inline"/>
              </ListItem>
              : null
             }
            {
            checkRole === 'admin' ?
            <ListItem button onClick={(e) => {setfragment("AddDevice")}}>
                <AddToQueueRounded color="primary" style={{marginRight:"4px"}}/>
                <ListItemText primary={"AddDevice"} display="inline"/>
            </ListItem>
            : null
            }
            {
              checkRole === 'admin' ?
              <ListItem button onClick={(e) => {setfragment("Alert")}}>
                  <AddAlertRounded color="primary" style={{marginRight:"4px"}}/>
                  <ListItemText primary={"Set Alerts"} display="inline"/>
              </ListItem>
              : null
             }        
          </List>
          <Divider />
          <List>            
            <ListItem button onClick={(e) => {setfragment("Logout")}}>
            <ExitToAppRounded color="primary" style={{marginRight:"4px"}}/>
            <ListItemText primary={"Logout"} display="inline"/>
            </ListItem>            
          </List>
          <Divider />
        </div>
      </Drawer>
      <main className={classes.content}>
        <Toolbar />
        {loadFragement()}   
      </main>
    </div>
  );
}
