import React, { Component } from 'react';
import {Container, Box, Typography, TextField, Button, LinearProgress, Select, MenuItem } from '@material-ui/core';
import axios from 'axios';


export class NumberAlertFragments extends Component {
    constructor() {
      super()
    
      this.state = {
        user : JSON.parse(localStorage.getItem('user')), 
        deviceId:"",
        deviceList:[],
        number1:"",
        number2:"",
        number1_error:null,
        number2_error:null,
        number3_error:null,
        show_progress: false,
        show_sucess: false,
      };
      
      this.handleChange = this.handleChange.bind()
      this.handleNumber = this.handleNumber.bind()
      this.setNumberAlert = this.setNumberAlert.bind()

    };
   

    componentDidMount(){
        let userName = (this.state.user !== null ? this.state.user.userId : null);
        axios.post('/home/alertDevice', {userId : userName}).then((res) => {
            console.log(res.data);
            console.log(res.data.deviceList[0]);
            this.setState({ 
                deviceList: res.data.deviceList,
                deviceId: res.data.deviceList[0]
             });
             axios.post('/home/alertData', {deviceId : this.state.deviceId}).then((res) => {
                this.setState({ 
                    number1:res.data.number1,
                    number2:res.data.number2
                });
            });

        });
    }

    
    handleChange = (e) => {
        this.setState({
            [e.target.name]:e.target.value
        })
    }

    handleNumber = (e) => {
        console.log(e)
        this.setState({
            deviceId:e.target.value,
            show_sucess: false,
            show_progress: false
        });

        axios.post('/home/alertData', {deviceId : e.target.value}).then((res) => {
            this.setState({ 
                number1:res.data.number1,
                number2:res.data.number2
            });
        });
    }

    setNumberAlert = (e) => {
        let data_valid = true;
               
        this.setState({
            number1_error:null,
            number2_error:null,
        })
        if(this.state.number1 === "" && this.state.number2 === ""){
            this.setState({
                number1_error:"Required!",
                number2_error:"Required!"
            })
            data_valid=false;
        }
        // if(this.state.number2 === ""){
        //     this.setState({
        //         number2_error:"Required!"
        //     })
        //     data_valid=false;
        // }
        // if(this.state.number3 === ""){
        //     this.setState({
        //         number3_error:"Required!"
        //     })
        //     data_valid=false;
        // }
        if(data_valid){
            this.setState({                
                show_progress: true
            })
        }
        if(data_valid){

            e.preventDefault()
            console.log("Set Number Alerts !!")
            axios
            .put('/home/numberAlert', {
                deviceId: this.state.deviceId,
                number1: this.state.number1 ,
                number2: this.state.number2
            })
            .then(response => {
                this.setState({
                    show_sucess: true,
                    show_progress: false
                })
                console.log('Number Alert Set Sucessfully !!')
            })            
        }
        this.setState({
            update:true
        }) 
    }


    render() {
        return (
            <Container maxWidth="xs">
                <Box bgcolor="#fafafa" boxShadow="3" borderRadius="12px" align='center' p='24px' mt="30px">     
                    <div>
                        <Typography varient="h5" color="Primary">
                            Select Your Device Id
                        </Typography>
                        <Select
                        labelId="select-label"
                        id="simple-select-email"
                        value={this.state.deviceId}
                        onChange={this.handleNumber}
                        fullWidth={true}
                        size="small" 
                        margin="normal"
                        align="center"
                        >
                            {
                                this.state.deviceList.map((device, i) => (
                                <MenuItem key={i} value={device} >{device}</MenuItem>
                                ))
                            }
                        </Select>
                    </div>
                    <br/>               
                    <Typography varient="h5" color="Primary">
                        Set Number Alert
                    </Typography>
                    <TextField name='number1' onChange={this.handleChange} error={this.state.number1_error != null} helperText={this.state.number1_error} value= {this.state.number1} label="Contact Number" id="numberId1" type="text" fullWidth={true} size="small" margin="normal"/>
                    <TextField name='number2'  onChange={this.handleChange} error={this.state.number2_error != null} helperText={this.state.number2_error} value= {this.state.number2} label="Contact Number" id="numberId2" type="text" fullWidth={true} size="small" margin="normal"/>
                    <br/>
                    <br/>
                    <Button variant="contained" onClick={this.setNumberAlert} size="large" color="primary" margin="normal" fullWidth={true}>
                        Set Alert
                    </Button>
                    <br/>
                    <br/>
                    {
                        this.state.show_sucess?
                        <Typography varient="h4" color="primary"> Number Alert Set Sucessfully !! </Typography>
                        :null
                    }
                    {
                        this.state.show_progress?
                        <LinearProgress color="primary" />
                        :null
                    }
                                        
                </Box>
            </Container>
        )
    }
}

export default NumberAlertFragments
