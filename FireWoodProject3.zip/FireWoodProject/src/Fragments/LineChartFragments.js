import React, {Component} from 'react';
import {Line} from 'react-chartjs-2';
import {Container, Box} from '@material-ui/core';
import axios from 'axios';

// const state = {
//   labels: ['January', 'February', 'March',
//            'April', 'May'],
//   datasets: [
//     {
//       label: 'Rainfall',
//       fill: true,
//       lineTension: 0.5,
//       backgroundColor: 'rgba(75,192,192,1)',
//       borderColor: 'rgba(0,0,0,1)',
//       borderWidth: 2,
//       data: [65, 59, 80, 81, 56]
//     }
//   ]
// }

export class LineChartFragments extends Component {
    constructor() {
        super()
      
        this.state = {
            lineData : {
                labels: ['January', 'February', 'March',
                        'April', 'May'],
                datasets: [
                    {
                        label: 'lbs',
                        fill: true,
                        lineTension: 0.5,
                        backgroundColor: 'rgba(75,192,192,1)',
                        borderColor: 'rgba(0,0,0,1)',
                        borderWidth: 2,
                        data: []
                    },
                    {
                        label: 'Revenue',
                        fill: true,
                        lineTension: 0.5,
                        backgroundColor: 'rgba(75,192,192,1)',
                        borderColor: 'rgba(0,0,0,1)',
                        borderWidth: 2,
                        data: [34, 9, 56, 98, 23]
                    }
                ]
            },
            lineStockData : {
                labels:[],
                datasets:[]
            }

        }; 
  
      };

    componentDidMount()
    {
        var amountStock = []
        var lbsStock = []
        var dateTimeStock = []
        axios
        .get('/home/chartData')
        .then(response => {
            var newData = response.data;
            console.log(newData);
            console.log(response.data[1].amount);
            for (var dataObj of newData)
            {
                dateTimeStock.push(dataObj.date_time);
                amountStock.push(parseFloat(dataObj.amount));
                lbsStock.push(parseInt(dataObj.vendlbs));
            }
            console.log(amountStock);
            console.log(lbsStock);
            console.log(dateTimeStock);
            this.setState(
                { 
                    lineStockData : {
                        labels: dateTimeStock,
                        datasets: [
                            {
                                label: 'lbs',
                                fill: false,
                                lineTension: 0.5,
                                backgroundColor: 'Sky Blue',
                                borderColor: 'Red',
                                borderWidth: 2,
                                data: lbsStock
                            },
                            {
                                label: 'Revenue',
                                fill: false,
                                lineTension: 0.5,
                                backgroundColor: 'Sky Blue',
                                borderColor: 'blue',
                                borderWidth: 2,
                                data: amountStock
                            }
                        ]
                    }                    
                });
        });
    }

  render() {
    return (
        <Container maxWidth="ms">
            <Box bgcolor="#fafafa" boxShadow="3" borderRadius="12px" align='center' p='24px' mt="10px" marginBottom="20px"> 
                <Line
                data={this.state.lineStockData}
                options={{
                    title:{
                    display:true,
                    text:'Stock Data Chart',
                    fontSize:20
                    },
                    legend:{
                    display:true,
                    position:'top'
                    },
                    hover: true
                }}
                />
            </Box>
        </Container>
    );
  }
}

export default LineChartFragments