-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 09, 2021 at 06:46 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.3.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `polarstationdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `alert`
--

CREATE TABLE `alert` (
  `Id` int(11) NOT NULL,
  `DeviceId` varchar(32) NOT NULL,
  `Email1` varchar(500) DEFAULT NULL,
  `Email2` varchar(500) DEFAULT NULL,
  `Email3` varchar(500) DEFAULT NULL,
  `Number1` varchar(50) DEFAULT NULL,
  `Number2` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `alert`
--

INSERT INTO `alert` (`Id`, `DeviceId`, `Email1`, `Email2`, `Email3`, `Number1`, `Number2`) VALUES
(1, 'device1', '', '', 'suraj.embatronix@gmail.com', '+917889521865', ''),
(2, 'device2', 'chauhanmunib5@gmail.com', 'shubham.jaiswal032@gmail.com', 'suraj.embatronix@gmail.com', '+917889521865', '+919988776655'),
(3, 'device3', '', 'shubham.jaiswal032@gmail.com', 'suraj.embatronix@gmail.com', '+917889521865', '+919988776655'),
(4, 'device4', 'chauhanmunib5@gmail.com', '', '', '+917889521865', '+919988776655'),
(5, 'device5', '', 'shubham.jaiswal032@gmail.com', 'suraj.embatronix@gmail.com', '+917889521865', '+919988776655'),
(6, 'device6', 'chauhanmunib5@gmail.com', '', '', '+917889521865', '+919988776655'),
(7, 'device7', 'chauhanmunib5@gmail.com', 'shubham.jaiswal032@gmail.com', 'suraj.embatronix@gmail.com', '+917889521865', '+919988776655'),
(8, 'device8', 'chauhanmunib5@gmail.com', 'shubham.jaiswal032@gmail.com', 'suraj.embatronix@gmail.com', '+917889521865', '+919988776655'),
(9, 'device9', '', 'shubham.jaiswal032@gmail.com', '', '+917889521865', '+919988776655'),
(10, 'device10', '', 'shubham.jaiswal032@gmail.com', '', '', '+919988776655'),
(11, 'device11', 'shubham.jaiswal032@gmail.com', 'shubham.jaiswal032@gmail.com', '', '+917889521865', '+919988776655'),
(12, 'device12', 'chauhanmunib5@gmail.com', '', '', '+917889521865', ''),
(13, 'device13', 'chauhanmunib5@gmail.com', '', 'suraj.embatronix@gmail.com', '+917889521865', '+919988776655'),
(14, 'device14', 'shubham.jaiswal032@gmail.com', '', '', '', '+919988776655'),
(15, 'device15', '', 'shubham.jaiswal032@gmail.com', 'suraj.embatronix@gmail.com', '+917889521865', '+919988776655'),
(16, 'device16', 'chauhanmunib5@gmail.com', '', 'suraj.embatronix@gmail.com', '+917889521865', '+919988776655'),
(17, 'device17', 'chauhanmunib5@gmail.com', '', '', '+917889521865', '+919988776655'),
(18, 'device18', '', 'shubham.jaiswal032@gmail.com', 'suraj.embatronix@gmail.com', '+917889521865', '+919988776655'),
(19, 'device19', '', 'shubham.jaiswal032@gmail.com', '', '+917889521865', '+919988776655'),
(20, 'device20', 'chauhanmunib5@gmail.com', 'shubham.jaiswal032@gmail.com', 'suraj.embatronix@gmail.com', '+917889521865', '+919988776655'),
(21, 'device21', 'chauhanmunib5@gmail.com', 'shubham.jaiswal032@gmail.com', 'suraj.embatronix@gmail.com', '+917889521865', '+919988776655'),
(22, 'device22', 'chauhanmunib5@gmail.com', 'shubham.jaiswal032@gmail.com', 'suraj.embatronix@gmail.com', '+917889521865', '+919988776655'),
(23, 'device23', '', 'shubham.jaiswal032@gmail.com', '', '+917889521865', '+919988776655'),
(24, 'device24', 'chauhanmunib5@gmail.com', '', 'suraj.embatronix@gmail.com', '+917889521865', '+919988776655'),
(25, 'device25', 'chauhanmunib5@gmail.com', 'shubham.jaiswal032@gmail.com', '', '+917889521865', '+919988776655'),
(26, 'device26', 'chauhanmunib5@gmail.com', '', 'suraj.embatronix@gmail.com', '+917889521865', '+919988776655'),
(27, 'device27', 'shubham.jaiswal032@gmail.com', '', 'suraj.embatronix@gmail.com', '+917889521865', '+919988776655'),
(28, 'device28', 'chauhanmunib5@gmail.com', 'shubham.jaiswal032@gmail.com', 'suraj.embatronix@gmail.com', '+917889521865', '+919988776655'),
(29, 'device29', '', 'shubham.jaiswal032@gmail.com', 'suraj.embatronix@gmail.com', '+917889521865', '+919988776655'),
(30, 'device30', 'chauhanmunib5@gmail.com', 'shubham.jaiswal032@gmail.com', 'suraj.embatronix@gmail.com', '+917889521865', '+919988776655'),
(31, 'device31', '', 'shubham.jaiswal032@gmail.com', '', '+917889521865', '+919988776655'),
(32, 'device32', 'chauhanmunib5@gmail.com', '', 'suraj.embatronix@gmail.com', '+917889521865', '+919988776655'),
(33, 'device33', '', 'shubham.jaiswal032@gmail.com', 'suraj.embatronix@gmail.com', '+917889521865', '+919988776655'),
(34, 'device43', 'chauhanmunib5@gmail.com', 'shubham.jaiswal032@gmail.com', 'suraj.embatronix@gmail.com', '+917889521865', '+919988776655'),
(35, 'device31', NULL, NULL, NULL, NULL, NULL),
(36, 'device46', NULL, NULL, NULL, NULL, NULL),
(37, 'device53', 'shubham.jaiswal032@gmail.com', '', '', '+917889521865', '');

-- --------------------------------------------------------

--
-- Table structure for table `device`
--

CREATE TABLE `device` (
  `Id` int(11) NOT NULL,
  `DeviceId` varchar(32) DEFAULT NULL,
  `UserId` int(5) DEFAULT NULL,
  `Location` varchar(100) DEFAULT NULL,
  `Status` int(11) DEFAULT NULL,
  `Control` int(11) DEFAULT NULL,
  `AvailableLbs` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `device`
--

INSERT INTO `device` (`Id`, `DeviceId`, `UserId`, `Location`, `Status`, `Control`, `AvailableLbs`) VALUES
(1, 'device1', 2, 'Lucknow', 1, 1, 900),
(2, 'device2', 3, 'Agara', 1, 1, 900),
(3, 'device3', 2, 'Noida', 0, 0, 1000),
(4, 'device4', 2, 'Mumbai', 0, 1, 700),
(5, 'device5', 2, 'Patna', 1, 0, 3457),
(6, 'device6', 3, 'Greater Noida', 1, 1, 5467),
(7, 'device7', 2, 'Punjab', 0, 0, 400),
(8, 'device8', 2, 'Ambala', 0, 0, 6785),
(9, 'device9', 3, 'Bangalore', 0, 0, 3457),
(10, 'device10', 2, 'Bangalore', 1, 1, 5000),
(11, 'device11', 2, 'Chennai', 0, 1, 3457),
(12, 'device12', 3, 'Hydrabad', 1, 1, 900),
(13, 'device13', 2, 'Amritsar', 1, 1, 6785),
(14, 'device14', 2, 'Goa', 1, 1, 6785),
(15, 'device15', 3, 'Goa', 1, 1, 10000),
(16, 'device16', 2, 'Allahbad', 1, 1, 10000),
(17, 'device17', 3, 'Kerla', 1, 1, 3457),
(18, 'device18', 3, 'Ranchi', 1, 1, 3457),
(19, 'device19', 2, 'Dhanbad', 1, 1, 98748),
(20, 'device20', 3, 'Bokaro', 1, 1, 10000),
(21, 'device21', 3, 'Cuttak', 1, 1, 6785),
(22, 'device22', 2, 'Kolkata', 1, 1, 10000),
(23, 'device23', 3, 'Kashmir', 1, 1, 3457),
(24, 'device24', 3, 'Gujrat', 1, 1, 3457),
(25, 'device25', 2, 'Ahmadabad', 1, 1, 6785),
(26, 'device26', 3, 'Chennai', 1, 1, 98748),
(27, 'device27', 3, 'Amritsar', 1, 1, 10000),
(28, 'device28', 2, 'Pune', 1, 1, 98748),
(29, 'device29', 3, 'Pune', 1, 1, 10000),
(30, 'device30', 3, 'Kolkata', 1, 1, 98748),
(31, 'device31', 4, 'Deoghar', 1, 1, 5700),
(32, 'device32', 4, 'Dumka', 1, 1, 7600),
(33, 'device33', 2, 'Dumka', 1, 0, 7600),
(34, 'Device34', 3, 'Deoghar', 0, 1, 5600),
(35, 'Device35', 2, 'Bangalore', 0, 1, 6700),
(36, 'device2', 5, 'Deoghar', 0, 1, 4000),
(37, 'Device12', 2, 'Deoghar', 0, 0, 0),
(38, 'device35', 2, 'Deoghar', 0, 0, 400),
(39, 'device46', 3, 'deoghar', 0, 0, 400),
(46, 'device51', 2, 'Deoghar', 0, 0, 0),
(47, 'device52', 5, 'Deoghar', 0, 0, 0),
(48, 'device53', 2, 'Deoghar', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `devicesetting`
--

CREATE TABLE `devicesetting` (
  `Id` int(11) NOT NULL,
  `DeviceId` varchar(32) NOT NULL,
  `UserId` int(5) NOT NULL,
  `CurrentLbs` int(10) DEFAULT NULL,
  `SoldLbs` int(10) DEFAULT NULL,
  `WarningLbs` int(10) DEFAULT NULL,
  `LeftDoorLU` int(1) DEFAULT NULL,
  `RightDoorLU` int(1) DEFAULT NULL,
  `LeftDoor` int(1) DEFAULT NULL,
  `RightDoor` int(1) DEFAULT NULL,
  `CurrentTemp` int(4) DEFAULT NULL,
  `Temperature` int(1) DEFAULT NULL,
  `VendTime` int(2) DEFAULT NULL,
  `LbsPrice` float DEFAULT NULL,
  `GTV` int(1) DEFAULT NULL,
  `Flag` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `devicesetting`
--

INSERT INTO `devicesetting` (`Id`, `DeviceId`, `UserId`, `CurrentLbs`, `SoldLbs`, `WarningLbs`, `LeftDoorLU`, `RightDoorLU`, `LeftDoor`, `RightDoor`, `CurrentTemp`, `Temperature`, `VendTime`, `LbsPrice`, `GTV`, `Flag`) VALUES
(1, 'device1', 2, 900, 30, 200, 0, 0, 1, 1, 45, 1, 5, 37.45, 1, 1),
(2, 'device2', 3, 900, 0, 200, 0, 0, 0, 0, 45, 1, 5, 37.45, 1, 1),
(3, 'device3', 2, 0, NULL, 1000, 0, 0, 0, 0, 36, 0, 3, 35.55, 1, 1),
(4, 'device4', 2, 0, NULL, 700, 1, 1, 0, 0, 36, 1, 5, 35.75, 1, 1),
(5, 'device5', 2, 10000, NULL, 3457, 1, 1, 1, 0, 36, 1, 5, 35.75, 1, 1),
(6, 'device6', 3, 0, NULL, 5467, 1, 1, 0, 0, 36, 1, 5, 35.75, 0, 0),
(7, 'device7', 2, 0, NULL, 400, 1, 1, 0, 1, 36, 1, 5, 35.75, 1, 0),
(8, 'device8', 2, 7896, NULL, 6785, 0, 1, 0, 0, 36, 1, 5, 35.75, 1, 0),
(9, 'device9', 3, 0, NULL, 700, 1, 1, 1, 0, 36, 1, 5, 35.75, 1, 0),
(10, 'device10', 2, 3000, NULL, 2000, 1, 1, 0, 0, 36, 1, 5, 35.75, 0, 0),
(11, 'device11', 2, 0, NULL, 100, 0, 1, 0, 0, 36, 1, 5, 35.75, 1, 0),
(12, 'device12', 3, 900, NULL, 200, 0, 0, 0, 0, 45, 1, 5, 37.45, 1, 0),
(13, 'device13', 2, 0, NULL, 100, 1, 0, 0, 0, 36, 1, 5, 35.75, 1, 0),
(14, 'device14', 2, 0, NULL, 200, 0, 1, 0, 0, 36, 1, 5, 35.75, 1, 0),
(15, 'device15', 3, 0, NULL, 340, 1, 1, 0, 0, 36, 1, 5, 35.75, 1, 0),
(16, 'device16', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(17, 'devie32', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(18, 'device35', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(19, 'device46', 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20, 'device52', 5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(21, 'device53', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `Id` int(11) NOT NULL,
  `DeviceId` varchar(32) DEFAULT NULL,
  `UserId` int(5) DEFAULT NULL,
  `CreditAmount` float DEFAULT NULL,
  `DebitAmount` float DEFAULT NULL,
  `VendLbs` int(10) DEFAULT NULL,
  `AvailableLbs` int(10) DEFAULT NULL,
  `DeviceDateTime` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `StockDate` date DEFAULT NULL,
  `StockTime` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`Id`, `DeviceId`, `UserId`, `CreditAmount`, `DebitAmount`, `VendLbs`, `AvailableLbs`, `DeviceDateTime`, `StockDate`, `StockTime`) VALUES
(1, 'device1', 2, 200.502, NULL, 20, 4000, '2020-11-06 12:26:08', NULL, NULL),
(2, 'device2', 3, 1000.1, NULL, 100, 10000, '2020-11-06 12:26:08', NULL, NULL),
(3, 'device3', 2, 200.502, NULL, 40, 1000, '2020-11-06 13:19:00', NULL, NULL),
(4, 'device4', 2, 1000.1, NULL, 60, 700, '2020-11-06 13:19:00', NULL, NULL),
(5, 'device5', 2, 5694.3, NULL, 80, 3457, '2020-11-06 13:19:00', NULL, NULL),
(6, 'device6', 3, 1000.1, NULL, 16, 5467, '2020-11-06 13:19:00', NULL, NULL),
(7, 'device7', 2, 200.1, NULL, 10, 400, '2020-11-06 13:19:00', NULL, NULL),
(8, 'device8', 2, 1000.1, NULL, 100, 6785, '2020-11-06 13:19:00', NULL, NULL),
(9, 'device9', 3, 5694.3, NULL, 100, 3457, '2020-11-06 13:19:00', NULL, NULL),
(10, 'device10', 2, 2000, NULL, 70, 5000, '2020-11-06 13:19:00', NULL, NULL),
(11, 'device11', 2, 765.6, NULL, 100, 3457, '2020-11-06 13:19:00', NULL, NULL),
(12, 'device12', 3, 765.6, NULL, 100, 900, '2020-12-30 12:29:28', NULL, NULL),
(13, 'device13', 2, 5694.3, NULL, 10, 6785, '2020-11-06 13:19:00', NULL, NULL),
(14, 'device14', 2, 1000.1, NULL, 100, 6785, '2020-11-06 13:19:00', NULL, NULL),
(15, 'device15', 3, 1000.1, NULL, 60, 10000, '2020-11-06 13:19:00', NULL, NULL),
(16, 'device16', 2, 345.6, NULL, 57, 10000, '2020-11-06 13:19:00', NULL, NULL),
(17, 'device17', 3, 345.6, NULL, 75, 3457, '2020-11-06 13:19:00', NULL, NULL),
(18, 'device18', 3, 1000.1, NULL, 60, 3457, '2020-11-06 13:19:00', NULL, NULL),
(19, 'device19', 2, 5694.3, NULL, 10, 98748, '2020-11-06 13:19:00', NULL, NULL),
(20, 'device20', 3, 765.6, NULL, 55, 10000, '2020-11-06 13:19:00', NULL, NULL),
(21, 'device21', 3, 345.6, NULL, 100, 6785, '2020-11-06 13:19:00', NULL, NULL),
(22, 'device22', 2, 1450.1, NULL, 587, 17645, '2020-11-06 13:51:16', NULL, NULL),
(23, 'device23', 3, 1000.1, NULL, 100, 3457, '2020-11-06 13:19:00', NULL, NULL),
(24, 'device24', 3, 765.6, NULL, 80, 3457, '2020-11-06 13:19:00', NULL, NULL),
(25, 'device25', 2, 345.6, NULL, 100, 6785, '2020-11-06 13:50:12', NULL, NULL),
(26, 'device26', 3, 345.6, NULL, 100, 98748, '2020-11-06 13:19:00', NULL, NULL),
(27, 'device27', 3, 345.6, NULL, 80, 10000, '2020-11-06 13:19:00', NULL, NULL),
(28, 'device28', 2, 765.6, NULL, 98, 98748, '2020-11-06 13:19:00', NULL, NULL),
(29, 'device29', 3, 1000.1, NULL, 10, 10000, '2020-11-06 13:19:00', NULL, NULL),
(30, 'device30', 3, 5694.3, NULL, 100, 98748, '2020-11-06 13:19:00', NULL, NULL),
(31, 'device12', 3, 10, 30, 100, 900, '2020-12-30 12:29:28', NULL, NULL),
(32, 'device12', 3, 10, 30, 100, 900, '2020-12-30 12:29:28', NULL, NULL),
(33, 'device12', 3, 30, NULL, NULL, 900, '2020-12-30 12:29:28', NULL, NULL),
(34, 'device12', 3, 30, NULL, NULL, 900, '2020-12-30 12:29:28', NULL, NULL),
(35, 'device12', 3, 30, NULL, NULL, 900, '2020-12-30 12:29:28', NULL, NULL),
(36, 'device12', 3, 30, NULL, NULL, 900, '2020-12-30 12:29:28', NULL, NULL),
(37, 'device12', 3, 30, NULL, NULL, 900, '2020-12-30 12:29:28', NULL, NULL),
(38, 'device12', 3, 30, NULL, NULL, 900, '2020-12-30 12:29:28', NULL, NULL),
(39, 'device12', 3, 0, 40, 100, 900, '2020-12-30 12:29:28', '2020-12-30', '12:22:23'),
(40, 'device12', 3, 10, 30, 100, 900, '2020-12-30 12:29:28', '2020-12-30', '12:20:44');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `Id` int(5) NOT NULL,
  `UserId` varchar(100) NOT NULL,
  `Password` varchar(500) NOT NULL,
  `Role` varchar(10) NOT NULL,
  `UserStatus` int(2) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`Id`, `UserId`, `Password`, `Role`, `UserStatus`) VALUES
(1, 'admin', '$2b$12$o.BufthIIKHcQMCAlVD.NulKceqFTv65oHrDe6rgmSHLwSQ6bA.TC', 'admin', 1),
(2, 'munib123', '$2b$12$M7EN6bP/wxauYs1eOFg3c.yS90ygnk/gKJaHf4YHYBc.WlBLxLiu.', 'admin', 0),
(3, 'suraj123', '$2b$12$WQf2.vDU62x9iF6JKf8GIe8/1rI3Z7g0nrXamn.oWFCPZwPxZ8V/m', 'user', 0),
(5, 'shubh123', '$2b$12$JGKwPrgF02XmyJFK2RB2DewPjAMERpB/cZTxahDPoK2V10DLz74b.', 'admin', 1),
(6, 'shubh21', '$2b$12$dkZ4fJJIxgzOJiLdgTqXbuDfDlWP/0942slGaTLVfnsudP3PDrjwK', 'user', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alert`
--
ALTER TABLE `alert`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_Alert_DeviceId` (`DeviceId`);

--
-- Indexes for table `device`
--
ALTER TABLE `device`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_Device_DeviceId` (`DeviceId`),
  ADD KEY `IX_Device_UserId` (`UserId`);

--
-- Indexes for table `devicesetting`
--
ALTER TABLE `devicesetting`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_DeviceSetting_DeviceId_Flag` (`DeviceId`,`Flag`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_UserId` (`UserId`),
  ADD KEY `IX_DeviceId` (`DeviceId`),
  ADD KEY `IX_DateTime` (`DeviceDateTime`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_User_UserId` (`UserId`),
  ADD KEY `IX_User_UserStatus` (`UserStatus`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alert`
--
ALTER TABLE `alert`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `device`
--
ALTER TABLE `device`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `devicesetting`
--
ALTER TABLE `devicesetting`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `Id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
