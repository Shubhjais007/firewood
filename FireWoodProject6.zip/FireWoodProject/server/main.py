from flask import Flask,jsonify,request,make_response
from flask_mysqldb import MySQL
from datetime import datetime
from flask_cors import CORS 
from flask_bcrypt import Bcrypt
from flask_jwt_extended import JWTManager
from flask_jwt_extended import create_access_token
from flask_mail import Mail, Message
from datetime import date, datetime
from twilio.rest import TwilioRestClient
from twilio.rest import Client
import os
import boto3

# Create an SNS client
clientaws = boto3.client(
    "sns",
    aws_access_key_id="AKIASEFYNSBSOEV2YEOD",
    aws_secret_access_key="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",
    region_name="us-east-2"
)

app=Flask(__name__)
mail = Mail(app) # instantiate the mail class

app.config['MYSQL_USER']='root'
app.config['MYSQL_PASSWORD']=''
app.config['MYSQL_DB']='polarstationdb'
app.config['MYSQL_CURSORCLASS']='DictCursor'
app.config['JWT_SECRET_KEY']='secret'

mysql=MySQL(app) 
   
# configuration of mail 
# app.config['MAIL_SERVER']='smtp.gmail.com'
# app.config['MAIL_PORT'] = 465
# app.config['MAIL_USERNAME'] = 'shubhk2712@gmail.com'
# app.config['MAIL_PASSWORD'] = 'Shubham@123#'
# app.config['MAIL_USE_TLS'] = False
# app.config['MAIL_USE_SSL'] = True
# mail = Mail(app) 

app.config['SECRET_KEY'] = 'top-secret!'
app.config['MAIL_SERVER'] = 'smtp.sendgrid.net'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'apikey'
app.config['MAIL_PASSWORD'] = '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'
app.config['MAIL_DEFAULT_SENDER'] = 'firewood2goalerts@gmail.com'
mail = Mail(app)

# Your Account Sid and Auth Token from twilio.com/console
# and set the environment variables. See http://twil.io/secure
#auth_token = os.environ['TWILIO_AUTH_TOKEN']
#account_sid = os.environ['TWILIO_ACCOUNT_SID']
#auth_token = 'AC190bd95f63b79fdde48bee3971547488'
#account_sid = 'c4e5ffaf9810d647491e3d2eff5dbbe9'


bcrypt=Bcrypt(app)
jwt=JWTManager(app)
CORS(app)


@app.route('/home/checkUser',methods=['POST'])
def checkUser():
    cur=mysql.connection.cursor()
    userId=str.lower(request.get_json()['userId'])

    cur.execute("SELECT * FROM user where UserId='"+str(userId)+"'")

    rv=cur.fetchone()

    result = {
        'userId':rv['UserId'],
        'role':rv['Role'],
        'status':rv['UserStatus']
    }

    return  jsonify({"result":result})


@app.route('/home/checkDevice',methods=['POST'])
def checkDevice():
    cur=mysql.connection.cursor()
    userId=str.lower(request.get_json()['userId'])

    cur.execute("SELECT * FROM user where UserId='"+str(userId)+"'")

    rv=cur.fetchone()

    result = {
        'userId':rv['UserId'],
        'role':rv['Role'],
        'status':rv['UserStatus']
    }

    return  jsonify({"result":result})

@app.route('/home/allDeviceName',methods=['GET'])
def allDeviceName():
    cur=mysql.connection.cursor()

    cur.execute("SELECT DeviceId FROM `device` ORDER BY Id ASC")

    res=cur.fetchall()
    deviceName = []

    for row in res:
        deviceName.append(row['DeviceId'])

    result = make_response(jsonify(deviceName), 200)

    return result

@app.route('/home/allUserName',methods=['GET'])
def allUserName():
    cur=mysql.connection.cursor()

    cur.execute("SELECT UserId FROM user where UserId!= 'admin' ORDER BY UserId ASC")

    res=cur.fetchall()
    userName = []

    for row in res:
        userName.append(row['UserId'])

    result = make_response(jsonify(userName), 200)
    
    return result

@app.route('/user/register',methods=['POST'])
def register():
    cur=mysql.connection.cursor()
    userId=str.lower(request.get_json()['userId'])
    password=bcrypt.generate_password_hash(request.get_json()['password']).decode('utf-8')
    role = str.lower(request.get_json()['role'])

    cur.execute("INSERT INTO user (UserId, Password, Role) VALUES ('"
    +str(userId)+"','"
    +str(password)+"','"
    +str(role)+"')"
    )

    mysql.connection.commit()

    result ={
     "userId": userId,
     "password":password,
     "role": role
    }
    return jsonify({"result":result})

@app.route('/user/login',methods=['POST'])
def login():
    cur=mysql.connection.cursor()
    userId=str.lower(request.get_json()['userId'])
    password=request.get_json()['password']
    result = ""
    cur.execute("SELECT * FROM user where UserId='"+str(userId)+"'")

    rv=cur.fetchone()

    print(rv)
    if rv :
        print(rv)
        if bcrypt.check_password_hash(rv['Password'],password):
            if rv['UserStatus'] == 1:
                access_token=create_access_token(identity={'userId':rv['UserId'],'role':rv['Role']})
                result=  ({'token':access_token, 'status': 1})
            else:
                result=jsonify({"error":"user live access revoked !!", 'status': 0, 'userError': 1})
        else:
            result=jsonify({"error":"invalid password !!", 'status': 0, 'userError': 0})
    else:
        result=jsonify({"error":"invalid username !!", 'status': 0, 'userError': 1})

    

    return result

@app.route('/home/userDetails',methods=['GET'])
def userDetails():
    cur=mysql.connection.cursor()    
    cur.execute("SELECT u.Id, u.UserId, u.Role, u.UserStatus FROM user as u WHERE u.UserId != 'admin'")

    res = cur.fetchall()    
    userDetail = []

    '''jsonify({"Result":res})`indx``Date_time``merchantId``StoreId``TerminalId`,
     `TransactionId`, `Amount`, `PaymentStatus`, `VendStatus`, `Balance`
    else:
        return make_response(jsonify({"message": "Request body must be JSON"}), 400)'''

    for row in res:
        response_body = {
            "id": row['Id'],
            "userId": row['UserId'],
            "role": row['Role'],
            "userStatus": row['UserStatus']
        }
        userDetail.append(response_body)

    result = make_response(jsonify(userDetail), 200)

    return result

@app.route('/home/updateUser',methods=['PUT'])
def updateUser():
    cur=mysql.connection.cursor()

    id=request.get_json()['id']
    role=str.lower(request.get_json()['role'])
    userStatus=request.get_json()['userStatus']

    cur.execute("UPDATE user SET Role ='"+ str(role) +"', UserStatus= '"+ str(userStatus) +"' WHERE Id = '"+ str(id) +"'")
    mysql.connection.commit()

    result ={
     "id":id,
     "role":role,
     "userStatus":userStatus
    }
    return jsonify({"result":result}, 200)

@app.route('/home/stock',methods=['GET'])
def merchant():
    cur=mysql.connection.cursor()    
    cur.execute("SELECT s.Id, s.DeviceDateTime, s.DeviceId, u.UserId, s.CreditAmount,s.DebitAmount, s.VendLbs, s.AvailableLbs FROM stock as s JOIN user as u on u.Id = s.UserId")

    res = cur.fetchall()    
    stockResp = []

    '''jsonify({"Result":res})`indx``Date_time``merchantId``StoreId``TerminalId`,
     `TransactionId`, `Amount`, `PaymentStatus`, `VendStatus`, `Balance`
    else:
        return make_response(jsonify({"message": "Request body must be JSON"}), 400)'''

    for row in res:
        response_body = {
            "id": row['Id'],
            "date_time": row['DeviceDateTime'],
            "deviceId": row['DeviceId'],
            "userId": row['UserId'],
            "amount": row['CreditAmount'],
            "debitAmount": row['DebitAmount'],
            "vendlbs": row['VendLbs'],
            "availablelbs": row['AvailableLbs']
        }
        stockResp.append(response_body)

    result = make_response(jsonify(stockResp), 200)

    return result

@app.route('/home/userStock',methods=['POST'])
def userTransaction():
    cur=mysql.connection.cursor()
    userId=request.get_json()['userId']

    cur.execute("SELECT s.Id, s.DeviceDateTime, s.DeviceId, u.UserId, s.CreditAmount,s.DebitAmount, s.VendLbs, s.AvailableLbs FROM stock as s join user as u on u.Id = s.UserId where u.userId ='"+str(userId)+"'")

    res = cur.fetchall()    
    stockResp = []
    
    '''jsonify({"Result":res})`indx``Date_time``merchantId``StoreId``TerminalId`,
     `TransactionId`, `Amount`, `PaymentStatus`, `VendStatus`, `Balance`
    else:
        return make_response(jsonify({"message": "Request body must be JSON"}), 400)'''

    for row in res:
        response_body = {
            "id": row['Id'],
            "date_time": row['DeviceDateTime'],
            "deviceId": row['DeviceId'],
            "userId": row['UserId'],
            "amount": row['CreditAmount'],
            "debitAmount": row['DebitAmount'],
            "vendlbs": row['VendLbs'],
            "availablelbs": row['AvailableLbs']
        }
        stockResp.append(response_body)

    result = make_response(jsonify(stockResp), 200)

    return result



@app.route('/home/device',methods=['GET'])
def device():
    cur=mysql.connection.cursor()    
    cur.execute("SELECT d.Id, d.DeviceId, d.Location, u.UserId, d.AvailableLbs, d.Control, d.Status FROM device as d JOIN user as u ON u.Id = d.UserId")

    res = cur.fetchall()    
    deviceRes = []
    
    '''jsonify({"Result":res})`indx``Date_time``merchantId``StoreId``TerminalId`,
     `TransactionId`, `Amount`, `PaymentStatus`, `VendStatus`, `Balance`
    else:
        return make_response(jsonify({"message": "Request body must be JSON"}), 400)'''

    for row in res:
        response_body = {
            "id": row['Id'],
            "deviceId": row['DeviceId'],
            "location": row['Location'],
            "userId": row['UserId'],
            "availablelbs": row['AvailableLbs'],
            "control": row['Control'],
            "status": row['Status']
        }
        deviceRes.append(response_body)

    result = make_response(jsonify(deviceRes), 200)

    return result


@app.route('/home/userDevice',methods=['POST'])
def userDevice():
    cur=mysql.connection.cursor()
    userId=request.get_json()['userId']

    cur.execute("SELECT d.Id, d.DeviceId, d.Location, u.UserId, d.AvailableLbs, d.Control, d.Status FROM device as d JOIN user as u ON u.Id = d.UserId where u.UserId='"+str(userId)+"'")

    res = cur.fetchall()    
    deviceRes = []
    
    '''jsonify({"Result":res})`indx``Date_time``merchantId``StoreId``TerminalId`,
     `TransactionId`, `Amount`, `PaymentStatus`, `VendStatus`, `Balance`
    else:
        return make_response(jsonify({"message": "Request body must be JSON"}), 400)'''

    for row in res:
        response_body = {
            "id": row['Id'],
            "deviceId": row['DeviceId'],
            "location": row['Location'],
            "userId": row['UserId'],
            "availablelbs": row['AvailableLbs'],
            "control": row['Control'],
            "status": row['Status']
        }
        deviceRes.append(response_body)

    result = make_response(jsonify(deviceRes), 200)

    return result


@app.route('/home/addDevice',methods=['PUT'])
def addDevice():
    cur=mysql.connection.cursor()

    deviceId=str.lower(request.get_json()['deviceId'])
    userId=str.lower(request.get_json()['userId'])
    location=request.get_json()['location']
    control=request.get_json()['control']
    status="0"
    availablelbs="0"

    cur.execute("INSERT INTO device (DeviceId,UserId,Location,Status,Control,AvailableLbs) VALUES ('"+str(deviceId)+"', (select Id from user where UserId = '"+str(userId)+"') ,'"+str(location)+"','"+str(status)+"','"+str(control)+"','"+str(availablelbs)+"')")

    mysql.connection.commit()

    cur.execute("INSERT INTO devicesetting (DeviceId, UserId) VALUES ('"+str(deviceId)+"', (select Id from user where UserId = '"+str(userId)+"'))")
   
    mysql.connection.commit()

    cur.execute("INSERT INTO alert (DeviceId) VALUES ('"+str(deviceId)+"')")
   
    mysql.connection.commit()


    result ={
     "deviceId":deviceId,
     "userId":userId,
     "location":location,
     "availablelbs":availablelbs,
     "control": control,
     "status" : "0"
    }
    return jsonify({"result":result}, 200)
 
@app.route('/home/addDeviceSettings',methods=['POST'])
def addDeviceSettings():
    cur=mysql.connection.cursor()

    deviceId=str.lower(request.get_json()['deviceId'])
    userId=str.lower(request.get_json()['userId'])

    cur.execute("INSERT INTO devicesetting (DeviceId, UserId) VALUES ('"+str(deviceId)+"', (select Id from user where UserId = '"+str(userId)+"'))")
    mysql.connection.commit()

    result ={
     "deviceId":deviceId,
     "userId":userId
    }
    return jsonify({"result":result}, 200)

@app.route('/home/addAlerts',methods=['POST'])
def addAlerts():
    cur=mysql.connection.cursor()

    deviceId=str.lower(request.get_json()['deviceId'])

    cur.execute("INSERT INTO alert (DeviceId) VALUES ('"+str(deviceId)+"')")
    mysql.connection.commit()


    result ={
     "deviceId":deviceId
    }
    return jsonify({"result":result}, 200)


@app.route('/home/deviceStatus', methods=['GET'])
def deviceStatus():
    cur=mysql.connection.cursor()    
    cur.execute("SELECT d.Id, d.DeviceId, d.Location, u.UserId, d.AvailableLbs, d.Control FROM device as d JOIN user as u ON u.Id = d.UserId")

    res = cur.fetchall()    
    deviceRes = []
    
    '''jsonify({"Result":res})`indx``Date_time``merchantId``StoreId``TerminalId`,
     `TransactionId`, `Amount`, `PaymentStatus`, `VendStatus`, `Balance`
    else:
        return make_response(jsonify({"message": "Request body must be JSON"}), 400)'''

    for row in res:
        response_body = {
            "id": row['Id'],
            "deviceId": row['DeviceId'],
            "location": row['Location'],
            "userId": row['UserId'],
            "availablelbs": row['AvailableLbs'],
            "control": row['Control']
        }
        deviceRes.append(response_body)

    result = make_response(jsonify(deviceRes), 200)

    return result



@app.route('/home/updateDevice',methods=['PUT'])
def updateDevice():
    cur=mysql.connection.cursor()
    id=request.get_json()['id']
    deviceId=str.lower(request.get_json()['deviceId'])
    userId=str.lower(request.get_json()['userId'])
    location=request.get_json()['location']
    control=request.get_json()['control']
    availablelbs=request.get_json()['availablelbs']

    cur.execute("UPDATE device SET DeviceId ='"+ str(deviceId) +"' , UserId= (select Id from user where UserId = '"+str(userId)+"'), Location = '"+ str(location) +"', Control= '"+ str(control) +"', AvailableLbs= '"+ str(availablelbs) +"' WHERE Id = '"+ str(id) +"'")
    mysql.connection.commit()

    cur.execute("UPDATE devicesetting SET Flag=1 WHERE DeviceId = '"+ str(deviceId) +"'")
    mysql.connection.commit()

    result ={
     "id":id,
     "deviceId":deviceId,
     "userId":userId,
     "location":location,
     "availablelbs":availablelbs,
     "control": control
    }
    return jsonify({"result":result}, 200)


@app.route('/home/chartData',methods=['GET'])
def chartData():
    cur=mysql.connection.cursor()    
    cur.execute("SELECT s.DeviceDateTime, s.CreditAmount, s.VendLbs FROM stock as s")

    res = cur.fetchall()    
    stockDataResp = []

    '''jsonify({"Result":res})`indx``Date_time``merchantId``StoreId``TerminalId`,
     `TransactionId`, `Amount`, `PaymentStatus`, `VendStatus`, `Balance`
    else:
        return make_response(jsonify({"message": "Request body must be JSON"}), 400)'''

    for row in res:
        response_body = {
            "date_time": row['DeviceDateTime'],
            "amount": row['CreditAmount'],
            "vendlbs": row['VendLbs']
        }
        stockDataResp.append(response_body)

    result = make_response(jsonify(stockDataResp), 200)

    return result


# @app.route('/home/emailAlert',methods=['PUT'])
# def emailAlert():
#     cur=mysql.connection.cursor()
    
#     email1=request.get_json()['email1']
#     email2=request.get_json()['email2']
#     email3=request.get_json()['email3']
    
#     cur.execute("UPDATE alert SET Email='"+ str(email1) +"' WHERE Id = '"+ str(1) +"'")
#     mysql.connection.commit()

#     cur.execute("UPDATE alert SET Email='"+ str(email2) +"' WHERE Id = '"+ str(2) +"'")
#     mysql.connection.commit()

#     cur.execute("UPDATE alert SET Email='"+ str(email3) +"' WHERE Id = '"+ str(3) +"'")
#     mysql.connection.commit()
 
#     result ={
#      "email1":email1,
#      "email2":email2,
#      "email3":email3
#     }
#     return jsonify({"result":result}, 200)

@app.route('/home/alertDevice',methods=['POST'])
def alertDevice():
    cur=mysql.connection.cursor()    
    userId=request.get_json()['userId']

    if(userId == 'admin'):
        cur.execute("SELECT d.DeviceId FROM device as d")
    else:
        cur.execute("SELECT d.DeviceId FROM device as d join user as u on u.Id = d.UserId where u.UserId = '"+ str(userId) +"'")

    res = cur.fetchall() 
    deviceList = []


    '''jsonify({"Result":res})`indx``Date_time``merchantId``StoreId``TerminalId`,
     `TransactionId`, `Amount`, `PaymentStatus`, `VendStatus`, `Balance`
    else:
        return make_response(jsonify({"message": "Request body must be JSON"}), 400)'''

    for row in res:
        deviceList.append(row["DeviceId"])

    result = make_response(jsonify({"deviceList" : deviceList}), 200)

    return result

@app.route('/home/emailAlert',methods=['PUT'])
def emailAlert():
    cur=mysql.connection.cursor()
    
    deviceId=request.get_json()['deviceId']
    email1=request.get_json()['email1']
    email2=request.get_json()['email2']
    email3=request.get_json()['email3']
    
    cur.execute("UPDATE alert SET Email1='"+ str(email1) +"', Email2='"+ str(email2) +"', Email3='"+ str(email3) +"' WHERE DeviceId = '"+ str(deviceId) +"'")
    mysql.connection.commit()

    result ={
        "deviceId":deviceId, 
        "email1":email1,
        "email2":email2,
        "email3":email3
    }
    return jsonify({"result":result}, 200)


@app.route('/home/numberAlert',methods=['PUT'])
def numberAlert():
    cur=mysql.connection.cursor()
    
    deviceId=request.get_json()['deviceId']
    number1=request.get_json()['number1']
    number2=request.get_json()['number2']
    
    cur.execute("UPDATE alert SET Number1='"+ str(number1) +"', Number2='"+ str(number2) +"' WHERE deviceId = '"+ str(deviceId) +"'")
    mysql.connection.commit()

    result ={
        "deviceId":deviceId,
        "number1":number1,
        "number2":number2
    }
    return jsonify({"result":result}, 200)
 

# @app.route('/home/numberAlert',methods=['PUT'])
# def numberAlert():
#     cur=mysql.connection.cursor()
    
#     number1=request.get_json()['number1']
#     number2=request.get_json()['number2']
#     number3=request.get_json()['number3']

#     cur.execute("UPDATE alert SET Number='"+ str(number1) +"' WHERE Id = 1")
#     mysql.connection.commit()

#     cur.execute("UPDATE alert SET Number='"+ str(number2) +"' WHERE Id = 2")
#     mysql.connection.commit()

#     cur.execute("UPDATE alert SET Number='"+ str(number3) +"' WHERE Id = 3")
#     mysql.connection.commit()

#     result ={
#      "number1":number1,
#      "number2":number2,
#      "number3":number3
#     }
#     return jsonify({"result":result}, 200)


@app.route('/home/alertData',methods=['POST'])
def alertData():
    cur=mysql.connection.cursor()    

    deviceId = str.lower(request.get_json()['deviceId'])

    print(deviceId)
    cur.execute("SELECT a.Email1, a.Email2, a.Email3, a.Number1, a.Number2 FROM alert as a WHERE a.DeviceId = '"+ str(deviceId) +"'")

    res = cur.fetchone()

    print(res)
    '''jsonify({"Result":res})`indx``Date_time``merchantId``StoreId``TerminalId`,
     `TransactionId`, `Amount`, `PaymentStatus`, `VendStatus`, `Balance`
    else:
        return make_response(jsonify({"message": "Request body must be JSON"}), 400)'''

    if res != None:
        response_body = {
                "email1": res['Email1'],
                "email2": res['Email2'],
                "email3": res['Email3'],
                "number1": res['Number1'],
                "number2": res['Number2']
            }
    else:
        response_body = {
            "email1": '',
            "email2": '',
            "email3": '',
            "number1": '',
            "number2": ''
        }

    result = make_response(jsonify(response_body), 200)

    return result

# @app.route('/home/alertData',methods=['GET'])
# def alertData():
#     cur=mysql.connection.cursor()    
#     cur.execute("SELECT a.Email, a.Number FROM alert as a")

#     res = cur.fetchall()    
#     stockDataResp = []

#     '''jsonify({"Result":res})`indx``Date_time``merchantId``StoreId``TerminalId`,
#      `TransactionId`, `Amount`, `PaymentStatus`, `VendStatus`, `Balance`
#     else:
#         return make_response(jsonify({"message": "Request body must be JSON"}), 400)'''

#     for row in res:
#         response_body = {
#             "email": row['Email'],
#             "number": row['Number']
#         }
#         stockDataResp.append(response_body)

#     result = make_response(jsonify(stockDataResp), 200)

#     return result


@app.route('/device/scan',methods=['POST'])
def scan():
    cur=mysql.connection.cursor()

    deviceId=str.lower(request.get_json()['DvcId'])
    userId=str.lower(request.get_json()['UsrId'])
    amount=request.get_json()['CAmount']
    availablelbs=request.get_json()['Albs']

    current_time = datetime.now() 
    todayDate = current_time.strftime("%Y-%m-%d")
    todayTime = current_time.strftime("%H:%M:%S")

    cur.execute("INSERT INTO stock(DeviceId, UserId, CreditAmount, AvailableLbs, StockDate, StockTime) VALUES ('"+str(deviceId)+"', (select Id from user where UserId = '"+str(userId)+"') ,'"+str(amount)+"','"+str(availablelbs)+"','"+str(todayDate)+"','"+str(todayTime) +"')")

    mysql.connection.commit()

    result = ""
    cur.execute("SELECT max(Id) as Id FROM stock")
    rv=cur.fetchone()

    result ={
        "Id":rv['Id'],
        "SerSettingF": 0,
	    "status":"successful"
    }
    return jsonify(result)


@app.route('/device/vendingSuccess',methods=['POST'])
def vendingSuccess():
    cur=mysql.connection.cursor()

    result = ""

    id=request.get_json()['Id']
    deviceId=str.lower(request.get_json()['DvcId'])
    # userId=request.get_json()['UsrId']
    amount=request.get_json()['CAmount']
    debitAmount=request.get_json()['DAmount']
    availablelbs=request.get_json()['Albs']
    vendlbs=request.get_json()['Rlbs']


    current_time = datetime.now() 
    todayDate = current_time.strftime("%Y-%m-%d")
    todayTime = current_time.strftime("%H:%M:%S")

    cur.execute("UPDATE stock SET CreditAmount = '"+ str(amount) +"', DebitAmount= '"+ str(debitAmount) +"', VendLbs= '"+ str(vendlbs) +"', AvailableLbs= '"+ str(availablelbs) +"', StockDate= '"+ str(todayDate)+"', StockTime= '"+ str(todayTime)+"' WHERE Id = '"+ str(id) +"'")
    mysql.connection.commit()

    cur.execute("UPDATE device SET AvailableLbs= '"+ str(availablelbs) +"' WHERE DeviceId = '"+ str(deviceId) +"'")
    mysql.connection.commit()

    cur.execute("UPDATE devicesetting SET CurrentLbs= '"+ str(availablelbs) +"' WHERE DeviceId = '"+ str(deviceId) +"'")
    mysql.connection.commit()
    
    result ={
        "SerSettingF": 0,
		"status":"successful"
    }
    return jsonify(result)


@app.route('/device/vendingFailed',methods=['POST'])
def vendingFailed():
    cur=mysql.connection.cursor()

    result = ""

    id=request.get_json()['Id']
    deviceId=str.lower(request.get_json()['DvcId'])
    # userId=request.get_json()['UsrId']
    amount=request.get_json()['CAmount']
    debitAmount=request.get_json()['DAmount']
    availablelbs=request.get_json()['Albs']
    vendlbs=request.get_json()['Rlbs']

    current_time = datetime.now() 
    todayDate = current_time.strftime("%Y-%m-%d")
    todayTime = current_time.strftime("%H:%M:%S")

    cur.execute("UPDATE stock SET CreditAmount = '"+ str(amount) +"', DebitAmount= '"+ str(debitAmount) +"', VendLbs= '"+ str(vendlbs) +"', AvailableLbs= '"+ str(availablelbs) +"', StockDate= '"+ str(todayDate)+"', StockTime= '"+ str(todayTime)+"' WHERE Id = '"+ str(id) +"'")
    mysql.connection.commit()

    cur.execute("UPDATE device SET AvailableLbs= '"+ str(availablelbs) +"' WHERE DeviceId = '"+ str(deviceId) +"'")
    mysql.connection.commit()

    cur.execute("UPDATE devicesetting SET CurrentLbs= '"+ str(availablelbs) +"' WHERE DeviceId = '"+ str(deviceId) +"'")
    mysql.connection.commit()

    result = {
        "SerSettingF": 0,
        "status" : "successful"
    }
    return jsonify(result)



@app.route('/device/sync',methods=['POST'])
def sync():
    cur=mysql.connection.cursor()

    # Send your sms message.
    account_sid = 'AC190bd95f63b79fdde48bee3971547488' 
    auth_token = 'c4e5ffaf9810d647491e3d2eff5dbbe9' 

    #id=request.get_json()['Id']
    deviceId=str.lower(request.get_json()['DvcId'])
    # userId=request.get_json()['UsrId']
    warning=request.get_json()['W_F']
    soldFlag=request.get_json()['S_F']
    doorFlag=request.get_json()['D_F']
    doorLeftLock=request.get_json()['L_DS']
    doorRightLock=request.get_json()['R_DS']
    doorLeft=request.get_json()['L_D']
    doorRight=request.get_json()['R_D']
    soldlbs=request.get_json()['Slbs']
    warninglbs=request.get_json()['Wlbs']
    availablelbs=request.get_json()['Albs']
    tempValue=request.get_json()['Temp']
    tempType=request.get_json()['T_t']
    vendTime=request.get_json()['V_T']
    priceLbs=request.get_json()['Prc']
    gtv=request.get_json()['Actv']
    flag=request.get_json()['Up_F']

    rv = ""
    result = ""

    cur.execute("UPDATE devicesetting SET CurrentLbs= '"+ str(availablelbs) +"', CurrentTemp= '"+ str(tempValue) +"', LeftDoor= '"+ str(doorLeft) +"', RightDoor= '"+ str(doorRight) +"' WHERE DeviceId = '"+ str(deviceId) +"'")
    mysql.connection.commit()
    
    cur.execute("UPDATE device SET AvailableLbs= '"+ str(availablelbs) +"' WHERE DeviceId = '"+ str(deviceId) +"'")
    mysql.connection.commit()


    if warning == 1 :
        cur=mysql.connection.cursor()    
        cur.execute("SELECT a.Email1, a.Email2, a.Email3, a.Number1, a.Number2, d.Location FROM alert as a JOIN device as d on d.DeviceId = a.DeviceId JOIN user as u on u.Id = d.UserId and u.UserStatus = 1 WHERE a.DeviceId ='"+ str(deviceId) +"'")

        deviceResp = cur.fetchone()    
        emailDataResp = []
        numberDataResp = []
        respBody = 'Please check your <b>'+ str(deviceId) +'</b> at <b>'+ str(deviceResp['Location']) +'</b>'
        respMobileBody = 'Please check your '+ str(deviceId) +' at '+ str(deviceResp['Location']) +'\nLow On Firewood \nFrom : Firewood2Go-Team'

        if deviceResp != None:
            if deviceResp['Email1'] != '':
                emailDataResp.append(deviceResp['Email1'])
            
            if deviceResp['Email2'] != '':
                emailDataResp.append(deviceResp['Email2'])

            if deviceResp['Email3'] != '':
                emailDataResp.append(deviceResp['Email3'])

            if deviceResp['Number1'] != '':
                numberDataResp.append(deviceResp['Number1'])
                client = Client(account_sid, auth_token) 
                message = client.messages.create( 
                                            from_='+15739841010',  
                                            body=respMobileBody,      
                                            to=str(deviceResp['Number1'])
                                        ) 
                print(message.sid)
            
            if deviceResp['Number2'] != '':
                numberDataResp.append(deviceResp['Number2'])
                client = Client(account_sid, auth_token) 
                message = client.messages.create( 
                                            from_='+15739841010',  
                                            body=respMobileBody,      
                                            to=str(deviceResp['Number2'])
                                        ) 
                print(message.sid)

        if emailDataResp != []:
            msg = Message('Low On Firewood ', recipients=emailDataResp)
            msg.body = (respBody + 
                        'Note: Please do not reply to this email'
                        'From'
                        'Firewood2Go-Team')
            msg.html = ('<h1>Low On Firewood </h1>'
                        '<p>' + respBody + '</p>'
                        '<p> Note: Please do not reply to this email</p>'
                        '<h4> From </h4>'
                        '<h4> Firewood2Go-Team </h4>')
            mail.send(msg)
    
    if soldFlag == 1 :
        cur=mysql.connection.cursor()    
        cur.execute("SELECT a.Email1, a.Email2, a.Email3, a.Number1, a.Number2, d.Location FROM alert as a JOIN device as d on d.DeviceId = a.DeviceId JOIN user as u on u.Id = d.UserId and u.UserStatus = 1 WHERE a.DeviceId ='"+ str(deviceId) +"'")

        deviceResp = cur.fetchone()    
        emailDataResp = []
        numberDataResp = []
        respBody = 'Please check your <b>'+ str(deviceId) +'</b> at <b>'+ str(deviceResp['Location']) +'</b>'
        respMobileBody = 'Please check your '+ str(deviceId) +' at '+ str(deviceResp['Location']) +'\nFirewood Sold Out \nFrom : Firewood2Go-Team'


        if deviceResp != None:
            if deviceResp['Email1'] != '':
                emailDataResp.append(deviceResp['Email1'])
            
            if deviceResp['Email2'] != '':
                emailDataResp.append(deviceResp['Email2'])

            if deviceResp['Email3'] != '':
                emailDataResp.append(deviceResp['Email3'])

            if deviceResp['Number1'] != '':
                numberDataResp.append(deviceResp['Number1'])
                client = Client(account_sid, auth_token) 
                message = client.messages.create( 
                                            from_='+15739841010',  
                                            body=respMobileBody,      
                                            to=str(deviceResp['Number1'])
                                        ) 
                print(message.sid)
            
            if deviceResp['Number2'] != '':
                numberDataResp.append(deviceResp['Number2'])
                client = Client(account_sid, auth_token) 
                message = client.messages.create( 
                                            from_='+15739841010',  
                                            body=respMobileBody,      
                                            to=str(deviceResp['Number2'])
                                        ) 
                print(message.sid)

        if emailDataResp != []:
            msg = Message('Firewood Sold Out ', recipients=emailDataResp)
            msg.body = (respBody + 
                        'Note: Please do not reply to this email'
                        'From'
                        'Firewood2Go-Team')
            msg.html = ('<h1>Firewood Sold Out </h1>'
                        '<p>' + respBody + '</p>'
                        '<p> Note: Please do not reply to this email</p>'
                        '<h4> From </h4>'
                        '<h4> Firewood2Go-Team </h4>')
            mail.send(msg)

    if doorFlag == 1 :
        cur=mysql.connection.cursor()    
        cur.execute("SELECT a.Email1, a.Email2, a.Email3, a.Number1, a.Number2, d.Location FROM alert as a JOIN device as d on d.DeviceId = a.DeviceId JOIN user as u on u.Id = d.UserId and u.UserStatus = 1 WHERE a.DeviceId ='"+ str(deviceId) +"'")

        deviceResp = cur.fetchone()    
        emailDataResp = []
        numberDataResp = []
        respBody = 'Please check your <b>'+ str(deviceId) +'</b> at <b>'+ str(deviceResp['Location']) +'</b>'
        respMobileBody = 'Please check your '+ str(deviceId) +' at '+ str(deviceResp['Location']) +'\nDoor(s) are Open \nFrom : Firewood2Go-Team'

        if deviceResp != None:
            if deviceResp['Email1'] != '':
                emailDataResp.append(deviceResp['Email1'])
            
            if deviceResp['Email2'] != '':
                emailDataResp.append(deviceResp['Email2'])

            if deviceResp['Email3'] != '':
                emailDataResp.append(deviceResp['Email3'])

            if deviceResp['Number1'] != '':
                numberDataResp.append(deviceResp['Number1'])
                client = Client(account_sid, auth_token) 
                message = client.messages.create( 
                                            from_='+15739841010',  
                                            body=respMobileBody,      
                                            to=str(deviceResp['Number1'])
                                        ) 
                print(message.sid)
            
            if deviceResp['Number2'] != '':
                numberDataResp.append(deviceResp['Number2'])
                client = Client(account_sid, auth_token) 
                message = client.messages.create( 
                                            from_='+15739841010',  
                                            body=respMobileBody,      
                                            to=str(deviceResp['Number2'])
                                        ) 
                print(message.sid)

        if emailDataResp != []:
            msg = Message('Door(s) are Open ', recipients=emailDataResp)
            msg.body = (respBody + 
                        'Note: Please do not reply to this email'
                        'From'
                        'Firewood2Go-Team')
            msg.html = ('<h1>Door(s) are Open </h1>'
                        '<p>' + respBody + '</p>'
                        '<p> Note: Please do not reply to this email</p>'
                        '<h4> From </h4>'
                        '<h4> Firewood2Go-Team </h4>')
            mail.send(msg)

    if flag == 1 :
       
        cur.execute("UPDATE devicesetting SET CurrentLbs= '"+ str(availablelbs) +"', SoldLbs= '"+ str(soldlbs)+"', WarningLbs= '"+ str(warninglbs) +"', LeftDoorLU= '"+ str(doorLeftLock) +"', RightDoorLU= '"+ str(doorRightLock) +"', CurrentTemp= '"+ str(tempValue) +"', Temperature= '"+ str(tempType) +"', VendTime= '"+ str(vendTime) +"',LbsPrice=  '"+ str(priceLbs) +"', GTV= '"+ str(gtv) +"', Flag=0 WHERE DeviceId = '"+ str(deviceId) +"'")
        mysql.connection.commit()

        cur.execute("UPDATE device SET Control= '"+ str(gtv) +"' WHERE DeviceId = '"+ str(deviceId) +"'")
        mysql.connection.commit()

        result ={
            "SerSettingF": 0,
		    "status":"successful"
        }
    else :
        cur.execute("SELECT Flag FROM devicesetting WHERE DeviceId = '"+ str(deviceId) +"'")
        rv = cur.fetchone()

        print("Inside if condition")
        print(rv['Flag'])
        if rv['Flag'] == 1 :
            cur.execute("SELECT SoldLbs, WarningLbs, LeftDoorLU, RightDoorLU, Temperature, VendTime, LbsPrice, GTV FROM devicesetting WHERE DeviceId = '"+ str(deviceId) +"'")
            res = cur.fetchone()

            result = {
                "SerSettingF": 1,
			    "status":"successful",
                "settings" : {
                    "Slbs":res['SoldLbs'],
                    "Wlbs":res['WarningLbs'],
                    "L_DS":res['LeftDoorLU'],
                    "R_DS":res['RightDoorLU'],
                    "T_t":res['Temperature'], 
                    "V_T":res['VendTime'],
                    "Prc":res['LbsPrice'],
                    "Actv":res['GTV'],
                }
            
            } 
            print(res['WarningLbs'])
        else:

            result = {
                "SerSettingF": 0,
		        "status":"successful"
            }

    return jsonify(result)



@app.route('/home/setting',methods=['GET'])
def setting():
    cur=mysql.connection.cursor()    
    cur.execute("SELECT s.Id, s.DeviceId, u.UserId, s.CurrentLbs, s.SoldLbs, s.WarningLbs, s.LeftDoorLU, s.RightDoorLU, s.LeftDoor, s.RightDoor, s.CurrentTemp, s.Temperature, s.VendTime, s.LbsPrice, s.GTV FROM devicesetting as s JOIN user as u ON u.Id = s.UserId")

    res = cur.fetchall()    
    settingRes = []
    
    '''jsonify({"Result":res})`indx``Date_time``merchantId``StoreId``TerminalId`,
     `TransactionId`, `Amount`, `PaymentStatus`, `VendStatus`, `Balance`
    else:
        return make_response(jsonify({"message": "Request body must be JSON"}), 400)'''

    for row in res:
        response_body = {
            "id": row['Id'],
            "deviceId": row['DeviceId'],
            "userId": row['UserId'],
            "currentLbs": row['CurrentLbs'],
            "soldLbs": row['SoldLbs'],
            "warningLbs": row['WarningLbs'],
            "leftDoorLU": row['LeftDoorLU'],
            "rightDoorLU": row['RightDoorLU'],
            "leftDoor": row['LeftDoor'],
            "rightDoor": row['RightDoor'],
            "currentTemp": row['CurrentTemp'],
            "temperature": row['Temperature'],
            "vendTime": row['VendTime'],
            "lbsPrice": row['LbsPrice'],
            "gtv": row['GTV']
        }
        settingRes.append(response_body)

    result = make_response(jsonify(settingRes), 200)

    return result


@app.route('/home/userSetting',methods=['POST'])
def userSetting():
    cur=mysql.connection.cursor()
    userId=str.lower(request.get_json()['userId'])

    cur.execute("SELECT s.Id, s.DeviceId, u.UserId, s.CurrentLbs, s.SoldLbs, s.WarningLbs, s.LeftDoorLU, s.RightDoorLU, s.LeftDoor, s.RightDoor, s.CurrentTemp, s.Temperature, s.VendTime, s.LbsPrice, s.GTV FROM devicesetting as s JOIN user as u ON u.Id = s.UserId where u.UserId='"+str(userId)+"'")

    res = cur.fetchall()    
    settingRes = []
    
    '''jsonify({"Result":res})`indx``Date_time``merchantId``StoreId``TerminalId`,
     `TransactionId`, `Amount`, `PaymentStatus`, `VendStatus`, `Balance`
    else:
        return make_response(jsonify({"message": "Request body must be JSON"}), 400)'''

    for row in res:
        response_body = {
            "id": row['Id'],
            "deviceId": row['DeviceId'],
            "userId": row['UserId'],
            "currentLbs": row['CurrentLbs'],
            "soldLbs": row['SoldLbs'],
            "warningLbs": row['WarningLbs'],
            "leftDoorLU": row['LeftDoorLU'],
            "rightDoorLU": row['RightDoorLU'],
            "leftDoor": row['LeftDoor'],
            "rightDoor": row['RightDoor'],
            "currentTemp": row['CurrentTemp'],
            "temperature": row['Temperature'],
            "vendTime": row['VendTime'],
            "lbsPrice": row['LbsPrice'],
            "gtv": row['GTV']
        }
        settingRes.append(response_body)

    result = make_response(jsonify(settingRes), 200)

    return result

@app.route('/home/updateSetting',methods=['PUT'])
def updateSetting():
    cur=mysql.connection.cursor()

    id=request.get_json()['id']
    soldLbs=request.get_json()['soldLbs']
    warningLbs=request.get_json()['warningLbs']
    leftDoorLU = request.get_json()['leftDoorLU']
    rightDoorLU = request.get_json()['rightDoorLU']
    temperature=request.get_json()['temperature']
    vendTime=request.get_json()['vendTime']
    lbsPrice=request.get_json()['lbsPrice']
    gtv = request.get_json()['gtv']

    cur.execute("UPDATE devicesetting SET soldLbs ='"+ str(soldLbs)+"' , WarningLbs = '"+ str(warningLbs) +"' , LeftDoorLU = '"+ str(leftDoorLU) +"' , RightDoorLU = '"+ str(rightDoorLU) +"' , Temperature = '"+ str(temperature) +"', VendTime= '"+ str(vendTime) +"', LbsPrice= '"+ str(lbsPrice) +"' , GTV = '"+ str(gtv) +"' , Flag=1 WHERE Id = '"+ str(id) +"'")
    mysql.connection.commit()

    result ={
     "id":id,
     "soldLbs":soldLbs,
     "warningLbs":warningLbs,
     "leftDoorLU":leftDoorLU,
     "rightDoorLU":rightDoorLU,
     "temperature":temperature,
     "vendTime":vendTime,
     "lbsPrice":lbsPrice,
     "gtv":gtv
    }
    return jsonify({"result":result}, 200)


# message object mapped to a particular URL ‘/’ 
@app.route('/device/sentAlert',methods=['GET'])
def sentAlert(): 
    cur=mysql.connection.cursor()    
    cur.execute("SELECT a.Email FROM alert as a")

    emailResp = cur.fetchall()    
    emailDataResp = []

    for row in emailResp:
        if row['Email'] != '':
            emailDataResp.append(row['Email'])

    print(emailDataResp)
    # print(emailDataResp[0])
    # print(emailDataResp[1])
    # print(emailDataResp[2])

    msg = Message('FireWood Twilio Test Email', recipients=emailDataResp)
    msg.body = ('Congratulations! You have sent a test email with '
                'FireWood Twilio!')
    msg.html = ('<h1>FireWood Twilio Test Email</h1>'
                '<p>Congratulations! You have sent a test email with '
                '<b>FireWood Twilio</b>!</p>')
    mail.send(msg)

    return 'Sent'


# @app.route('/', methods=['GET', 'POST'])
# def index():
#     if request.method == 'POST':
#         recipient = request.form['recipient']
#         msg = Message('Twilio SendGrid Test Email', recipients=[recipient])
#         msg.body = ('Congratulations! You have sent a test email with '
#                     'Twilio SendGrid!')
#         msg.html = ('<h1>Twilio SendGrid Test Email</h1>'
#                     '<p>Congratulations! You have sent a test email with '
#                     '<b>Twilio SendGrid</b>!</p>')
#         mail.send(msg)
#         flash(f'A test message was sent to {recipient}.')
#         return redirect(url_for('index'))
#     return render_template('index.html')


# if __name__ == '__main__': 
#    app.run(debug = True) 

@app.route('/home/getDateTime',methods=['GET'])
def getDateTime():
    
    today = date.today()
    
    # Month abbreviation, day and year	
    d4 = today.strftime("%d-%m-%Y")
    print("d4 =", d4)

    current_time = datetime.now() 
    todayDate = current_time.strftime("%d-%m-%Y")
    todayTime = current_time.strftime("%H:%M:%S")

    # Printing attributes of now().  
    print ("The attributes of now() are : ")  
    
    print ("Today : ", end = "")  
    print (todayDate)
    
    print ("Today : ", end = "")  
    print (todayDate)  
    todayYear = current_time.year
    print ("Year : ", end = "")  
    print (current_time.year)  
    todayMonth = current_time.month
    print ("Month : ", end = "")  
    print (current_time.month)  
    todayDay = current_time.day
    print ("Day : ", end = "")  
    print (current_time.day)  
    todayHour = current_time.hour
    print ("Hour : ", end = "")  
    print (current_time.hour)  
    todayMinute = current_time.minute
    print ("Minute : ", end = "")  
    print (current_time.minute)  
    todaySecond = current_time.second
    print ("Second : ", end = "")  
    print (current_time.second)  
    todayMicroSecond = current_time.microsecond
    print ("Microsecond : ", end = "")  
    print (current_time.microsecond)


    response_body = {
        "todayDate": today,
        "todaysDate":todayDate,
        "todayTime":todayTime,
        "todayYear": todayYear,
        "todayMonth": todayMonth,
        "todayDay": todayDay,
        "todayHour": todayHour,
        "todayMinute": todayMinute,
        "todaySecond": todaySecond,
        "todayMicroSecond": todayMicroSecond
    }
    result = make_response(jsonify(response_body), 200)

    return result

# message object mapped to a particular URL ‘/’ 
@app.route('/home/sentSMSAlert',methods=['GET'])
def sentSMSAlert(): 
    # Send your sms message.
    clientaws.publish(
        PhoneNumber="+16362634094",
        Message="Hello Terrance!! Aleart from FireWood Dashboard test3"
    )

    return 'Sent'

# message object mapped to a particular URL ‘/’ 
@app.route('/home/sentTwilioSMSAlert',methods=['POST'])
def sentTwilioSMSAlert(): 
    cur=mysql.connection.cursor()    

    # Send your sms message.
    account_sid = 'AC190bd95f63b79fdde48bee3971547488' 
    auth_token = 'c4e5ffaf9810d647491e3d2eff5dbbe9' 

    deviceId=str.lower(request.get_json()['DvcId'])
    print(deviceId)

    cur.execute("SELECT a.Number1, a.Number2 FROM alert as a JOIN device as d on d.DeviceId = a.DeviceId JOIN user as u on u.Id = d.UserId and u.UserStatus = 1 WHERE a.DeviceId ='"+ str(deviceId) +"'")

    numberResp = cur.fetchone()    
    numberDataResp = []

    if numberResp != None:
        if numberResp['Number1'] != '':
            numberDataResp.append(numberResp['Number1'])
            client = Client(account_sid, auth_token) 
            message = client.messages.create( 
                                        from_='+15739841010',  
                                        body='Testing SMS from FireWood APIs 1st Number',      
                                        to=str(numberResp['Number1'])
                                    ) 
            print(message.sid)
        
        if numberResp['Number2'] != '':
            numberDataResp.append(numberResp['Number2'])
            client = Client(account_sid, auth_token) 
            message = client.messages.create( 
                                        from_='+15739841010',  
                                        body='Testing SMS from FireWood APIs 2nd Number',      
                                        to=str(numberResp['Number1'])
                                    ) 
            print(message.sid)
    
    print(numberResp)
    print(numberDataResp)
    print(numberResp['Number1'])
    print(str(numberResp['Number1']))

    client = Client(account_sid, auth_token) 
    message = client.messages.create( 
                                from_='+15739841010',  
                                body='Testing SMS from FireWood APIs Outside loop ',      
                                to='+917889521865'
                            ) 
    print(message.sid)

    return 'Sent'


if(__name__=='__main__'):
    app.run(host='172.31.29.181',debug=True,port=5000)