import React, { Component } from 'react';
import {Container, Box, Typography, TextField, Button, LinearProgress, Select, MenuItem   } from '@material-ui/core';
import axios from 'axios';

export class EmailAlertFragments extends Component {
    constructor() {
      super()
    
      this.state = {
        user : JSON.parse(localStorage.getItem('user')), 
        deviceId:"",
        deviceList:[],
        email1:"",
        email2:"",
        email3:"",
        email1_error:null,
        email2_error:null,
        email3_error:null,
        show_progress: false,
        show_sucess: false,
      };
      
      this.handleChange = this.handleChange.bind()
      this.handleEmail = this.handleEmail.bind()
      this.setEmailAlert = this.setEmailAlert.bind()

    };

    componentDidMount(){  

        let userName = (this.state.user !== null ? this.state.user.userId : null);
        axios.post('/home/alertDevice', {userId : userName}).then((res) => {
            console.log(res.data);
            console.log(res.data.deviceList[0]);
            this.setState({ 
                deviceList: res.data.deviceList,
                deviceId: res.data.deviceList[0]
             });
             axios.post('/home/alertData', {deviceId : this.state.deviceId}).then((res) => {
                this.setState({ 
                    email1:res.data.email1,
                    email2:res.data.email2,
                    email3:res.data.email3
                });
            });

        });
    }
   
    handleChange = (e) => {
        this.setState({
            [e.target.name]:e.target.value
        })
    }

    handleEmail = (e) => {
        console.log(e)
        this.setState({
            deviceId:e.target.value,
            show_sucess: false,
            show_progress: false
        });
        this.setState({
            email1_error:null,
            email2_error:null,
            email3_error:null,
        })

        axios.post('/home/alertData', {deviceId : e.target.value}).then((res) => {
            this.setState({ 
                email1:res.data.email1,
                email2:res.data.email2,
                email3:res.data.email3
            });
        });
    }

    setEmailAlert = (e) => {
        let data_valid = true;
               
        this.setState({
            email1_error:null,
            email2_error:null,
            email3_error:null,
        })
        if(this.state.email1 === "" && this.state.email2 === "" && this.state.email3 === ""){
            this.setState({
                email1_error:"Required!",
                email2_error:"Required!",
                email3_error:"Required!"
            })
            data_valid=false;
        }
        // if(this.state.email2 === ""){
        //     this.setState({
        //         email2_error:"Required!"
        //     })
        //     data_valid=false;
        // } 
        // if(this.state.email3 === ""){
        //     this.setState({
        //         email3_error:"Required!"
        //     })
        //     data_valid=false;
        // }

        


        if(data_valid){
            this.setState({                
                show_progress: true
            })
        }
        if(data_valid){

            e.preventDefault()
            console.log("Email Alert Set !!")
            axios
            .put('/home/emailAlert', {
                deviceId: this.state.deviceId,
                email1: this.state.email1 ,
                email2: this.state.email2 ,
                email3: this.state.email3 
            })
            .then(response => {
                this.setState({     
                    show_sucess: true,
                    show_progress: false
                })
                console.log('Alert Email Set Successfully !!')
            })                        
        }
        this.setState({
            update:true
        }) 
    }


    render() {
        return (
            <Container maxWidth="xs">
                <Box bgcolor="#fafafa" boxShadow="3" borderRadius="12px" align='center' p='24px' mt="30px">  
                    <div>
                        <Typography varient="h5" color="Primary">
                            Select Your Device Id
                        </Typography>
                        <Select
                        labelId="select-label"
                        id="simple-select-email"
                        value={this.state.deviceId}
                        onChange={this.handleEmail}
                        fullWidth={true}
                        size="small" 
                        margin="normal"
                        align="center"
                        >
                            {
                                this.state.deviceList.map((device, i) => (
                                <MenuItem key={i} value={device} >{device}</MenuItem>
                                ))
                            }
                        </Select>
                    </div>
                    <br/>
                    <Typography varient="h5" color="Primary">
                        Set Email Alert
                    </Typography>
                    <TextField name='email1' onChange={this.handleChange} error={this.state.email1_error != null} helperText={this.state.email1_error} label="Email Id" id="emailId1" value= {this.state.email1} type="text" fullWidth={true} size="small" margin="normal"/>
                    <TextField name='email2'  onChange={this.handleChange} error={this.state.email2_error != null} helperText={this.state.email2_error} label="Email Id" id="emailId2" type="text"   value= {this.state.email2} fullWidth={true} size="small" margin="normal"/>                    
                    <TextField name='email3' onChange={this.handleChange} error={this.state.email3_error != null} helperText={this.state.email3_error} label="Email Id" id="emailId3" type="text"  value= {this.state.email3} fullWidth={true} size="small" margin="normal"/>
                    <br/>
                    <br/>
                    <Button variant="contained" onClick={this.setEmailAlert} size="large" color="primary" margin="normal" fullWidth={true}>
                        Set Alert
                    </Button>
                    <br/>
                    <br/>
                    {
                        this.state.show_sucess?
                        <Typography varient="h4" color="primary">Email Alert Set Sucessfully !! </Typography>
                        :null
                    }
                    {
                        this.state.show_progress?
                        <LinearProgress color="primary" />
                        :null
                    }
                                        
                </Box>
            </Container>
        )
    }
}

export default EmailAlertFragments
