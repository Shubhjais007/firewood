import React, { Component } from 'react';
import {Container, Box, Typography, Button, LinearProgress, Select, MenuItem } from '@material-ui/core';
import MuiPhoneNumber from 'material-ui-phone-number';
import axios from 'axios';


export class NumberAlertFragments extends Component {
    constructor() {
      super()
    
      this.state = {
        user : JSON.parse(localStorage.getItem('user')), 
        deviceId:"",
        deviceList:[],
        number1:"",
        number2:"",
        number1_error:null,
        number2_error:null,
        number3_error:null,
        show_progress: false,
        show_sucess: false,
      };
      
      this.handleChange = this.handleChange.bind();
      this.handleNumber = this.handleNumber.bind();
      this.setNumberAlert = this.setNumberAlert.bind();
      this.handleChangeNumber1 = this.handleChangeNumber1.bind(this);
      this.handleChangeNumber2 = this.handleChangeNumber2.bind(this);
    };
   

    componentDidMount(){
        let userName = (this.state.user !== null ? this.state.user.userId : null);
        axios.post('/home/alertDevice', {userId : userName}).then((res) => {
            console.log(res.data);
            console.log(res.data.deviceList[0]);
            this.setState({ 
                deviceList: res.data.deviceList,
                deviceId: res.data.deviceList[0]
             });
             axios.post('/home/alertData', {deviceId : this.state.deviceId}).then((res) => {
                this.setState({ 
                    number1:res.data.number1,
                    number2:res.data.number2
                });
            });

        });
    }

    
    handleChange = (e) => {
        this.setState({
            [e.target.name]:e.target.value
        })
    }

    handleChangeNumber1(value) {
        if (value) {
        this.setState({ number1: value });
        }
    }

    handleChangeNumber2(value) {
        if (value) {
        this.setState({ number2: value });
        }
    }

    handleNumber = (e) => {
        console.log(e)
        this.setState({
            deviceId:e.target.value,
            show_sucess: false,
            show_progress: false
        });

        this.setState({
            number1_error:null,
            number2_error:null,
        })

        axios.post('/home/alertData', {deviceId : e.target.value}).then((res) => {
            this.setState({ 
                number1:res.data.number1,
                number2:res.data.number2
            });
        });
    }

    setNumberAlert = (e) => {
        let data_valid = true;             
        this.setState({
            number1_error:null,
            number2_error:null,
        })
        if(this.state.number1 === "" && this.state.number2 === ""){
            this.setState({
                number1_error:"Required!",
                number2_error:"Required!"
            })
            data_valid=false;
        }
        // if(this.state.number2 === ""){
        //     this.setState({
        //         number2_error:"Required!"
        //     })
        //     data_valid=false;
        // }
        // if(this.state.number3 === ""){
        //     this.setState({
        //         number3_error:"Required!"
        //     })
        //     data_valid=false;
        // }
        if(data_valid){
            this.setState({                
                show_progress: true
            })
        }
        if(data_valid){

            e.preventDefault()
            console.log("Set Number Alerts !!")
            axios
            .put('/home/numberAlert', {
                deviceId: this.state.deviceId,
                number1: this.state.number1 ,
                number2: this.state.number2
            })
            .then(response => {
                this.setState({
                    show_sucess: true,
                    show_progress: false
                })
                console.log('Number Alert Set Sucessfully !!')
            })            
        }
        this.setState({
            update:true
        }) 
    }


    render() {
        return (
            <Container maxWidth="xs">
                <Box bgcolor="#fafafa" boxShadow="3" borderRadius="12px" align='center' p='24px' mt="30px">     
                    <div>
                        <Typography varient="h5" color="Primary">
                            Select Your Device Id
                        </Typography>
                        <Select
                        labelId="select-label"
                        id="simple-select-email"
                        value={this.state.deviceId}
                        onChange={this.handleNumber}
                        fullWidth={true}
                        size="small" 
                        margin="normal"
                        align="center"
                        >
                            {
                                this.state.deviceList.map((device, i) => (
                                <MenuItem key={i} value={device} >{device}</MenuItem>
                                ))
                            }
                        </Select>
                    </div>
                    <br/>               
                    <Typography varient="h5" color="Primary">
                        Set Number Alert
                    </Typography>
                    <MuiPhoneNumber
                        name="number1"
                        label="Phone Number"
                        data-cy="user-phone"
                        autoFormat={false}
                        disableAreaCodes={true}
                        defaultCountry={"us"}
                        value={this.state.number1}
                        onChange={this.handleChangeNumber1}
                        error={this.state.number1_error != null}
                        helperText={this.state.number1_error}
                        fullWidth={true}
                        size="small" 
                        margin="normal"
                    />
                    <MuiPhoneNumber
                        name="number2"
                        label="Phone Number"
                        data-cy="user-phone"
                        autoFormat={false}
                        disableAreaCodes={true}
                        defaultCountry={"us"}
                        value={this.state.number2}
                        onChange={this.handleChangeNumber2}
                        error={this.state.number2_error != null}
                        helperText={this.state.number2_error}
                        fullWidth={true}
                        size="small" 
                        margin="normal"
                    />
                    <br/>
                    <br/>
                    <Button variant="contained" onClick={this.setNumberAlert} size="large" color="primary" margin="normal" fullWidth={true}>
                        Set Alert
                    </Button>
                    <br/>
                    <br/>
                    {
                        this.state.show_sucess?
                        <Typography varient="h4" color="primary"> Number Alert Set Sucessfully !! </Typography>
                        :null
                    }
                    {
                        this.state.show_progress?
                        <LinearProgress color="primary" />
                        :null
                    }
                                        
                </Box>
            </Container>
        )
    }
}

export default NumberAlertFragments
