
// Firebase App (the core Firebase SDK) is always required and
// must be listed before other Firebase SDKs
import * as firebase from "firebase/app";

// Add the Firebase services that you want to use
import "firebase/auth";
import "firebase/firestore";


var firebaseConfig = {
  apiKey: "AIzaSyDTIhV0Up-BKSK8XMFgTXkTkd-c5x0Qmxw",
  authDomain: "firewood-aec40.firebaseapp.com",
  projectId: "firewood-aec40",
  storageBucket: "firewood-aec40.appspot.com",
  messagingSenderId: "690692862293",
  appId: "1:690692862293:web:c9158e2e37e0af62f07fdc",
  measurementId: "G-X88XR9G7B6"
};

  // Initialize Firebase
firebase.initializeApp(firebaseConfig);

export const firebaseAuth = firebase.auth();
export const firestore = firebase.firestore();

export default firebase;